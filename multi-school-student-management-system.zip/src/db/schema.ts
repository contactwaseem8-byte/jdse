import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

/* ---------------------------------- Schools ---------------------------------- */

export const schools = pgTable("schools", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull().unique(),
  address: text("address"),
  contactPhone: text("contact_phone"),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
});

/* ----------------------------------- Users ----------------------------------- */

export const userRoles = ["super_admin", "admin", "school"] as const;
export type UserRole = (typeof userRoles)[number];

export const userStatuses = ["pending", "approved", "rejected"] as const;
export type UserStatus = (typeof userStatuses)[number];

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    username: text("username").notNull().unique(),
    passwordHash: text("password_hash").notNull(),
    fullName: text("full_name").notNull(),
    role: text("role", { enum: userRoles }).notNull(),
    status: text("status", { enum: userStatuses }).notNull().default("pending"),
    schoolId: integer("school_id").references(() => schools.id, {
      onDelete: "set null",
    }),
    /** For school registrations that requested a brand-new school */
    requestedSchoolName: text("requested_school_name"),
    createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  },
  (t) => [index("users_school_idx").on(t.schoolId)],
);

/* ------------------------- Custom field definitions -------------------------- */

export const fieldTypes = ["text", "number", "date", "select", "textarea"] as const;
export type FieldType = (typeof fieldTypes)[number];

export const fieldDefinitions = pgTable(
  "field_definitions",
  {
    id: serial("id").primaryKey(),
    schoolId: integer("school_id")
      .notNull()
      .references(() => schools.id, { onDelete: "cascade" }),
    label: text("label").notNull(),
    fieldKey: text("field_key").notNull(),
    type: text("type", { enum: fieldTypes }).notNull().default("text"),
    options: jsonb("options").$type<string[]>().notNull().default([]),
    required: boolean("required").notNull().default(false),
    enabled: boolean("enabled").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  },
  (t) => [
    uniqueIndex("fields_school_key_unique").on(t.schoolId, t.fieldKey),
    index("fields_school_idx").on(t.schoolId),
  ],
);

/* ---------------------------------- Students --------------------------------- */

export const students = pgTable(
  "students",
  {
    id: serial("id").primaryKey(),
    schoolId: integer("school_id")
      .notNull()
      .references(() => schools.id, { onDelete: "cascade" }),
    /** Globally unique, never reused. Rendered zero-padded e.g. 0001 */
    serialNumber: integer("serial_number").notNull(),
    className: text("class_name").notNull(),
    /** Photo stored on disk, renamed to its serial e.g. "0001.jpg" */
    photoFile: text("photo_file").notNull(),
    customData: jsonb("custom_data").$type<Record<string, string>>().notNull().default({}),
    createdBy: integer("created_by").references(() => users.id, {
      onDelete: "set null",
    }),
    createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
  },
  (t) => [
    uniqueIndex("students_serial_unique").on(t.serialNumber),
    index("students_school_idx").on(t.schoolId),
    index("students_class_idx").on(t.className),
  ],
);

/* ------------------------------ Serial counters ------------------------------ */

export const counters = pgTable("counters", {
  id: text("id").primaryKey(),
  value: integer("value").notNull().default(0),
});

export type School = typeof schools.$inferSelect;
export type User = typeof users.$inferSelect;
export type FieldDefinition = typeof fieldDefinitions.$inferSelect;
export type Student = typeof students.$inferSelect;
