"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { toast } from "sonner";
import { Loader2, UserRoundX, UserRoundCheck } from "lucide-react";

interface PendingUser {
  id: number;
  username: string;
  fullName: string;
  role: string;
  schoolName: string | null;
  requestedSchoolName: string | null;
  createdAt: string;
}

export function ApprovalsCard() {
  const [pending, setPending] = useState<PendingUser[] | null>(null);
  const [busyId, setBusyId] = useState<number | null>(null);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/users", { cache: "no-store" });
      const d = await res.json();
      setPending((d.users ?? []).filter((u: PendingUser & { status: string }) => u.status === "pending"));
    } catch {
      setPending([]);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function act(id: number, status: "approved" | "rejected") {
    setBusyId(id);
    try {
      const res = await fetch(`/api/users/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || "Action failed");
      toast.success(status === "approved" ? "Account approved" : "Account rejected");
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Action failed");
    } finally {
      setBusyId(null);
    }
  }

  if (!pending || pending.length === 0) return null;

  return (
    <section className="card rise rise-1 border-amber/40 bg-amber/5 p-5">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <span className="relative flex size-2.5">
            <span className="absolute inline-flex size-full animate-ping rounded-full bg-amber opacity-60" />
            <span className="relative inline-flex size-2.5 rounded-full bg-amber" />
          </span>
          <h2 className="text-sm font-semibold">
            {pending.length} account{pending.length === 1 ? "" : "s"} awaiting approval
          </h2>
        </div>
        <Link
          href="/dashboard/users"
          className="flex items-center gap-1 text-[13px] font-semibold text-cobalt hover:underline"
        >
          Manage all →
        </Link>
      </div>

      <div className="grid gap-2.5 md:grid-cols-2">
        {pending.slice(0, 4).map((u) => (
          <div
            key={u.id}
            className="flex items-center justify-between gap-3 rounded-xl border border-line bg-cream p-3.5"
          >
            <div className="min-w-0">
              <p className="truncate text-[13.5px] font-semibold">{u.fullName}</p>
              <p className="truncate font-mono text-[11px] text-mute">
                @{u.username} · {u.role === "admin" ? "admin" : "school user"} ·{" "}
                {u.schoolName ?? u.requestedSchoolName ?? "—"}
              </p>
            </div>
            <div className="flex shrink-0 gap-1.5">
              <button
                onClick={() => act(u.id, "approved")}
                disabled={busyId === u.id}
                className="grid size-8 place-items-center rounded-lg border border-moss/40 text-moss transition-colors hover:bg-moss hover:text-white"
                title="Approve"
              >
                {busyId === u.id ? (
                  <Loader2 className="size-4 spin" />
                ) : (
                  <UserRoundCheck className="size-4" />
                )}
              </button>
              <button
                onClick={() => act(u.id, "rejected")}
                disabled={busyId === u.id}
                className="grid size-8 place-items-center rounded-lg border border-clay/40 text-clay transition-colors hover:bg-clay hover:text-white"
                title="Reject"
              >
                <UserRoundX className="size-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
