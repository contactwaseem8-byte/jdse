"use client";

import { useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Building2,
  LayoutDashboard,
  LogOut,
  Menu,
  School as SchoolIcon,
  SlidersHorizontal,
  UserPlus,
  Users,
  X,
} from "lucide-react";

type Role = "super_admin" | "admin" | "school";

interface NavItem {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const NAV: Record<Role, NavItem[]> = {
  super_admin: [
    { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
    { href: "/dashboard/users", label: "Users & Approvals", icon: Users },
    { href: "/dashboard/schools", label: "Schools", icon: Building2 },
    { href: "/dashboard/students", label: "All Students", icon: SchoolIcon },
  ],
  admin: [
    { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
    { href: "/dashboard/students", label: "All Students", icon: SchoolIcon },
  ],
  school: [
    { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
    { href: "/dashboard/students", label: "Students", icon: SchoolIcon },
    { href: "/dashboard/students/new", label: "Add Student", icon: UserPlus },
    { href: "/dashboard/fields", label: "Form Fields", icon: SlidersHorizontal },
  ],
};

const ROLE_LABEL: Record<Role, string> = {
  super_admin: "Super Admin",
  admin: "Admin",
  school: "School User",
};

export function DashboardShell({
  role,
  fullName,
  username,
  schoolName,
  schoolCode,
  children,
}: {
  role: Role;
  fullName: string;
  username: string;
  schoolName: string | null;
  schoolCode: string | null;
  children: ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const items = NAV[role];

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.replace("/login");
    router.refresh();
  }

  const nav = (
    <nav className="flex flex-col gap-1">
      {items.map((item) => {
        const active =
          item.href === "/dashboard"
            ? pathname === item.href
            : pathname === item.href ||
              (pathname.startsWith(item.href + "/") &&
                !(item.href === "/dashboard/students" && pathname === "/dashboard/students/new"));
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={() => setOpen(false)}
            className={`group flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-[13.5px] font-medium transition-all ${
              active
                ? "bg-cobalt text-white shadow-[0_10px_24px_-12px_rgba(34,64,214,0.9)]"
                : "text-cream/65 hover:text-cream hover:bg-cream/[0.06]"
            }`}
          >
            <item.icon
              className={`size-[17px] ${active ? "text-white" : "text-cream/40 group-hover:text-cream/80"}`}
            />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );

  const identity = (
    <div className="rounded-xl border border-cream/10 bg-cream/[0.04] p-3.5">
      <div className="flex items-center gap-3">
        <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-cream/10 font-mono text-xs font-semibold text-cream">
          {fullName.slice(0, 2).toUpperCase()}
        </span>
        <div className="min-w-0">
          <p className="truncate text-[13px] font-semibold text-cream">{fullName}</p>
          <p className="truncate font-mono text-[10px] text-cream/45">@{username}</p>
        </div>
      </div>
      {schoolName && (
        <p className="mt-2.5 truncate border-t border-cream/10 pt-2.5 font-mono text-[10px] uppercase tracking-widest text-cream/45">
          {schoolCode} · {schoolName}
        </p>
      )}
      <button
        onClick={logout}
        className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg border border-cream/15 px-3 py-2 text-[12px] font-semibold text-cream/70 transition-colors hover:border-clay/60 hover:bg-clay/15 hover:text-[#ff9d85]"
      >
        <LogOut className="size-3.5" />
        Sign out
      </button>
    </div>
  );

  return (
    <div className="flex min-h-dvh">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[248px] flex-col justify-between bg-ink p-4 lg:flex">
        <div>
          <Link href="/dashboard" className="mb-7 flex items-center gap-3 px-2 pt-1">
            <span className="grid size-9 place-items-center rounded-xl bg-cobalt font-mono text-sm font-semibold text-white">
              EV
            </span>
            <div>
              <p className="text-[15px] font-semibold leading-tight tracking-tight text-cream">
                EduVault
              </p>
              <p className="font-mono text-[9px] uppercase tracking-[0.22em] text-cream/40">
                {ROLE_LABEL[role]}
              </p>
            </div>
          </Link>
          {nav}
        </div>
        {identity}
      </aside>

      {/* Mobile top bar */}
      <div className="fixed inset-x-0 top-0 z-40 flex items-center justify-between border-b border-line-dark bg-ink px-4 py-3 lg:hidden">
        <Link href="/dashboard" className="flex items-center gap-2.5">
          <span className="grid size-8 place-items-center rounded-lg bg-cobalt font-mono text-xs font-semibold text-white">
            EV
          </span>
          <span className="text-sm font-semibold text-cream">EduVault</span>
        </Link>
        <button
          onClick={() => setOpen(true)}
          className="grid size-9 place-items-center rounded-lg border border-cream/15 text-cream"
          aria-label="Open menu"
        >
          <Menu className="size-4" />
        </button>
      </div>

      {/* Mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-ink/60 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          />
          <aside className="absolute inset-y-0 left-0 flex w-[280px] flex-col justify-between bg-ink p-4 shadow-2xl">
            <div>
              <div className="mb-6 flex items-center justify-between px-1 pt-1">
                <span className="font-mono text-[10px] uppercase tracking-[0.24em] text-cream/40">
                  Navigate
                </span>
                <button
                  onClick={() => setOpen(false)}
                  className="grid size-8 place-items-center rounded-lg border border-cream/15 text-cream"
                  aria-label="Close menu"
                >
                  <X className="size-4" />
                </button>
              </div>
              {nav}
            </div>
            {identity}
          </aside>
        </div>
      )}

      {/* Content */}
      <div className="flex-1 lg:pl-[248px] pt-[60px] lg:pt-0">
        <div className="mx-auto max-w-[1180px] px-4 py-6 sm:px-8 sm:py-9">{children}</div>
      </div>
    </div>
  );
}
