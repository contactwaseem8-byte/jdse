"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Camera, ImageIcon, Loader2, RefreshCcw, SwitchCamera, Trash2, X, Zap } from "lucide-react";
import { formatBytes } from "@/lib/format";

const MAX_DIMENSION = 1600;
const JPEG_QUALITY = 0.86;

export interface CapturedPhoto {
  file: File;
  previewUrl: string;
  originalBytes: number;
  compressedBytes: number;
}

/** Compress an image source down to a storage-friendly, high-quality JPEG. */
async function compressImage(source: Blob, fromCamera: boolean): Promise<CapturedPhoto> {
  const bitmap = await createImageBitmap(source);
  const scale = Math.min(1, MAX_DIMENSION / Math.max(bitmap.width, bitmap.height));
  const w = Math.max(1, Math.round(bitmap.width * scale));
  const h = Math.max(1, Math.round(bitmap.height * scale));

  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d")!;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(bitmap, 0, 0, w, h);
  bitmap.close();

  let quality = JPEG_QUALITY;
  let blob = await new Promise<Blob | null>((res) =>
    canvas.toBlob(res, "image/jpeg", quality),
  );
  // One retry if still chunky — halves storage with no visible quality loss.
  if (blob && blob.size > 3 * 1024 * 1024) {
    quality = 0.74;
    blob = await new Promise<Blob | null>((res) =>
      canvas.toBlob(res, "image/jpeg", quality),
    );
  }
  if (!blob) throw new Error("Could not process the image.");

  const file = new File([blob], fromCamera ? "capture.jpg" : "photo.jpg", {
    type: "image/jpeg",
  });
  return {
    file,
    previewUrl: URL.createObjectURL(blob),
    originalBytes: source.size,
    compressedBytes: blob.size,
  };
}

export function PhotoCapture({
  value,
  onChange,
}: {
  value: CapturedPhoto | null;
  onChange: (photo: CapturedPhoto | null) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [busy, setBusy] = useState(false);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setCameraOpen(false);
  }, []);

  useEffect(() => stopCamera, [stopCamera]);

  async function openCamera() {
    setCameraError(null);
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraError("Camera is not supported on this device — please upload a photo instead.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 1920 } },
        audio: false,
      });
      streamRef.current = stream;
      setCameraOpen(true);
      requestAnimationFrame(() => {
        if (videoRef.current) videoRef.current.srcObject = stream;
      });
    } catch {
      setCameraError("Camera permission denied — please upload a photo instead.");
    }
  }

  async function captureFromCamera() {
    const video = videoRef.current;
    if (!video || busy) return;
    setBusy(true);
    try {
      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth || 1280;
      canvas.height = video.videoHeight || 960;
      canvas.getContext("2d")!.drawImage(video, 0, 0);
      const blob = await new Promise<Blob | null>((res) =>
        canvas.toBlob(res, "image/jpeg", 0.95),
      );
      if (!blob) throw new Error();
      const photo = await compressImage(blob, true);
      if (value) URL.revokeObjectURL(value.previewUrl);
      onChange(photo);
      stopCamera();
      toast.success("Photo captured & compressed");
    } catch {
      toast.error("Could not capture the photo.");
    } finally {
      setBusy(false);
    }
  }

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    if (!f.type.startsWith("image/")) {
      toast.error("Please choose an image file.");
      return;
    }
    setBusy(true);
    try {
      const photo = await compressImage(f, false);
      if (value) URL.revokeObjectURL(value.previewUrl);
      onChange(photo);
      toast.success("Photo compressed & ready");
    } catch {
      toast.error("Could not read that image.");
    } finally {
      setBusy(false);
    }
  }

  const savedPct = value ? Math.max(0, Math.round((1 - value.compressedBytes / value.originalBytes) * 100)) : 0;

  return (
    <div>
      {value ? (
        <div className="overflow-hidden rounded-2xl border border-line bg-cream">
          <div className="relative">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={value.previewUrl}
              alt="Captured student"
              className="h-64 w-full object-cover"
            />
            <div className="absolute inset-x-0 bottom-0 flex items-center justify-between bg-gradient-to-t from-ink/85 to-transparent px-4 pb-3 pt-10 text-cream">
              <div className="flex items-center gap-2 font-mono text-[11px]">
                <Zap className="size-3.5 text-[#ffd97a]" />
                <span>
                  {formatBytes(value.originalBytes)} → {formatBytes(value.compressedBytes)}
                </span>
                <span className="rounded bg-moss/90 px-1.5 py-0.5 text-[10px] font-semibold">
                  −{savedPct}%
                </span>
              </div>
              <span className="font-mono text-[10px] uppercase tracking-widest text-cream/60">
                saved as serial .jpg
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                URL.revokeObjectURL(value.previewUrl);
                onChange(null);
              }}
              className="absolute right-3 top-3 grid size-9 place-items-center rounded-lg bg-ink/70 text-cream backdrop-blur transition-colors hover:bg-clay"
              aria-label="Remove photo"
            >
              <Trash2 className="size-4" />
            </button>
          </div>
          <div className="flex items-center gap-2 px-4 py-3">
            <button type="button" onClick={openCamera} className="btn btn-ghost btn-sm">
              <SwitchCamera className="size-3.5" /> Retake
            </button>
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="btn btn-ghost btn-sm"
            >
              <RefreshCcw className="size-3.5" /> Replace file
            </button>
          </div>
        </div>
      ) : (
        <div className="rounded-2xl border-2 border-dashed border-line bg-cream/70 p-6 text-center">
          <span className="mx-auto grid size-14 place-items-center rounded-2xl bg-cobalt/10 text-cobalt">
            <Camera className="size-6" />
          </span>
          <p className="mt-3 text-sm font-semibold">Student photo — mandatory</p>
          <p className="mx-auto mt-1 max-w-xs text-xs leading-relaxed text-mute">
            Captured on the spot or uploaded. Auto-compressed and renamed to the
            student&apos;s unique serial, e.g. <span className="font-mono">0004.jpg</span>.
          </p>
          {cameraError && (
            <p className="mx-auto mt-2 max-w-xs text-xs font-medium text-clay">{cameraError}</p>
          )}
          <div className="mt-4 flex flex-wrap items-center justify-center gap-2.5">
            <button type="button" onClick={openCamera} className="btn btn-primary" disabled={busy}>
              {busy ? <Loader2 className="size-4 spin" /> : <Camera className="size-4" />}
              Open camera
            </button>
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="btn btn-ghost"
              disabled={busy}
            >
              <ImageIcon className="size-4" />
              Upload photo
            </button>
          </div>
        </div>
      )}

      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFile}
      />

      {/* Camera modal */}
      {cameraOpen && (
        <div className="fixed inset-0 z-[100] grid place-items-center bg-ink/85 p-4 backdrop-blur-sm">
          <div className="w-full max-w-lg overflow-hidden rounded-2xl border border-cream/10 bg-ink shadow-2xl">
            <div className="flex items-center justify-between px-4 py-3">
              <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-cream/50">
                Live capture
              </p>
              <button
                onClick={stopCamera}
                className="grid size-8 place-items-center rounded-lg border border-cream/15 text-cream/70 hover:text-cream"
                aria-label="Close camera"
              >
                <X className="size-4" />
              </button>
            </div>
            <div className="relative aspect-[4/3] bg-black">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="size-full object-cover"
              />
              <div className="pointer-events-none absolute inset-6 rounded-xl border-2 border-cream/25" />
            </div>
            <div className="flex items-center justify-center gap-3 px-4 py-4">
              <button
                onClick={captureFromCamera}
                disabled={busy}
                className="btn btn-primary !rounded-full !px-8 !py-3"
              >
                {busy ? <Loader2 className="size-4 spin" /> : <Camera className="size-4" />}
                Capture
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
