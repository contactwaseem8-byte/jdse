"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { toast } from "sonner";
import {
  ArrowDownUp,
  Download,
  Eye,
  FileSpreadsheet,
  FolderArchive,
  Loader2,
  PencilLine,
  Search,
  School as SchoolIcon,
  Trash2,
  UserPlus,
  X,
} from "lucide-react";
import { EmptyState, SerialStamp } from "@/components/ui";
import type { FieldVM } from "@/components/students/StudentForm";

type Role = "super_admin" | "admin" | "school";

export interface SchoolOpt {
  id: number;
  name: string;
  code: string;
}

interface StudentRow {
  id: number;
  serialNumber: number;
  className: string;
  photoFile: string;
  customData: Record<string, string>;
  createdAt: string;
  updatedAt: string;
  schoolId: number;
  schoolName: string;
  schoolCode: string;
}

interface ApiResponse {
  students: StudentRow[];
  classes: string[];
  fields: Record<string, FieldVM[]>;
}

const SORTS = [
  { v: "serial_asc", label: "Serial · low → high" },
  { v: "serial_desc", label: "Serial · high → low" },
  { v: "class_asc", label: "Class · A → Z" },
  { v: "newest", label: "Newest first" },
];

export function StudentsExplorer({
  role,
  schools,
}: {
  role: Role;
  schools: SchoolOpt[];
}) {
  const [data, setData] = useState<ApiResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [debouncedQ, setDebouncedQ] = useState("");
  const [className, setClassName] = useState("");
  const [schoolId, setSchoolId] = useState("");
  const [sort, setSort] = useState("serial_asc");
  const [pendingDelete, setPendingDelete] = useState<StudentRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setDebouncedQ(q.trim()), 320);
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, [q]);

  const queryString = useCallback(() => {
    const p = new URLSearchParams();
    if (debouncedQ) p.set("q", debouncedQ);
    if (className) p.set("className", className);
    if (schoolId) p.set("schoolId", schoolId);
    if (sort) p.set("sort", sort);
    const s = p.toString();
    return s ? `?${s}` : "";
  }, [debouncedQ, className, schoolId, sort]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/students${queryString()}`, { cache: "no-store" });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "Load failed");
      setData(d);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not load students.");
    } finally {
      setLoading(false);
    }
  }, [queryString]);

  useEffect(() => {
    load();
  }, [load]);

  async function confirmDelete() {
    if (!pendingDelete) return;
    setDeleting(true);
    try {
      const res = await fetch(`/api/students/${pendingDelete.id}`, { method: "DELETE" });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || "Delete failed");
      toast.success(`Serial #${String(pendingDelete.serialNumber).padStart(4, "0")} deleted`);
      setPendingDelete(null);
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Delete failed");
    } finally {
      setDeleting(false);
    }
  }

  const students = data?.students ?? [];
  const canEdit = role === "school";

  // Dynamic preview columns: fields of the currently relevant school
  const previewFields: FieldVM[] = useMemo(() => {
    if (!data) return [];
    const ids = Object.keys(data.fields).map(Number);
    const targetId =
      role === "school"
        ? ids[0]
        : schoolId
          ? Number(schoolId)
          : ids.length === 1
            ? ids[0]
            : null;
    if (!targetId) return [];
    return (data.fields[targetId] ?? []).slice(0, 3);
  }, [data, role, schoolId]);

  const multiSchool = role !== "school" && !schoolId;

  return (
    <div className="rise rise-1">
      {/* Toolbar */}
      <div className="card mb-4 flex flex-wrap items-center gap-2.5 p-3">
        <div className="relative min-w-[220px] flex-1">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-mute" />
          <input
            className="input pl-10"
            placeholder="Search serial, name, class, any field…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          {q && (
            <button
              onClick={() => setQ("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-mute hover:text-ink"
              aria-label="Clear search"
            >
              <X className="size-4" />
            </button>
          )}
        </div>

        {role !== "school" && (
          <select
            className="select w-auto min-w-[180px]"
            value={schoolId}
            onChange={(e) => setSchoolId(e.target.value)}
          >
            <option value="">All schools</option>
            {schools.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        )}

        <select
          className="select w-auto min-w-[150px]"
          value={className}
          onChange={(e) => setClassName(e.target.value)}
        >
          <option value="">All classes</option>
          {(data?.classes ?? []).map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>

        <div className="relative">
          <ArrowDownUp className="absolute left-3 top-1/2 size-3.5 -translate-y-1/2 text-mute" />
          <select
            className="select w-auto pl-9"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
          >
            {SORTS.map((s) => (
              <option key={s.v} value={s.v}>
                {s.label}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2 border-l border-line pl-2.5">
          <a
            href={`/api/export/excel${queryString()}`}
            className="btn btn-ghost btn-sm"
            title="Download Excel with unique serials"
          >
            <FileSpreadsheet className="size-4 text-moss" />
            Excel
          </a>
          <a
            href={`/api/export/zip${queryString()}`}
            className="btn btn-ghost btn-sm"
            title="Download ZIP folder of serial-named photos + Excel"
          >
            <FolderArchive className="size-4 text-cobalt" />
            ZIP
          </a>
          {canEdit && (
            <Link href="/dashboard/students/new" className="btn btn-primary btn-sm">
              <UserPlus className="size-4" /> Add
            </Link>
          )}
        </div>
      </div>

      {/* Table */}
      {loading && !data ? (
        <div className="card grid place-items-center py-24">
          <Loader2 className="size-6 spin text-mute" />
        </div>
      ) : students.length === 0 ? (
        <EmptyState
          icon={<SchoolIcon className="size-6" />}
          title={debouncedQ || className ? "No matches found" : "No students yet"}
          description={
            debouncedQ || className
              ? "Try a different search term or clear the filters."
              : canEdit
                ? "Add your first student — the record gets a unique serial and the photo is renamed to it automatically."
                : "Students registered by schools will appear here."
          }
          action={
            canEdit ? (
              <Link href="/dashboard/students/new" className="btn btn-primary">
                <UserPlus className="size-4" /> Add student
              </Link>
            ) : undefined
          }
        />
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Serial</th>
                  <th>Photo</th>
                  {multiSchool && <th>School</th>}
                  <th>Class</th>
                  {previewFields.map((f) => (
                    <th key={f.fieldKey}>{f.label}</th>
                  ))}
                  <th className="!text-right">Actions</th>
                </tr>
              </thead>
              <tbody className={loading ? "opacity-50 transition-opacity" : "transition-opacity"}>
                {students.map((s) => (
                  <tr key={s.id}>
                    <td>
                      <SerialStamp serial={s.serialNumber} />
                    </td>
                    <td>
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={`/api/photos/${s.photoFile}?v=${new Date(s.updatedAt).getTime()}`}
                        alt=""
                        loading="lazy"
                        className="size-11 rounded-lg border border-line object-cover"
                      />
                    </td>
                    {multiSchool && (
                      <td>
                        <p className="max-w-[190px] truncate font-medium">{s.schoolName}</p>
                        <p className="font-mono text-[10px] uppercase tracking-wider text-mute">
                          {s.schoolCode}
                        </p>
                      </td>
                    )}
                    <td className="whitespace-nowrap font-medium">{s.className}</td>
                    {previewFields.map((f) => (
                      <td key={f.fieldKey} className="max-w-[200px] truncate text-ink/85">
                        {s.customData[f.fieldKey] || <span className="text-mute/60">—</span>}
                      </td>
                    ))}
                    <td>
                      <div className="flex items-center justify-end gap-1">
                        <Link
                          href={`/dashboard/students/${s.id}`}
                          className="grid size-8 place-items-center rounded-lg border border-transparent text-mute transition-colors hover:border-line hover:bg-cream hover:text-ink"
                          title="View"
                        >
                          <Eye className="size-4" />
                        </Link>
                        {canEdit && (
                          <>
                            <Link
                              href={`/dashboard/students/${s.id}?edit=1`}
                              className="grid size-8 place-items-center rounded-lg border border-transparent text-mute transition-colors hover:border-line hover:bg-cream hover:text-ink"
                              title="Edit"
                            >
                              <PencilLine className="size-4" />
                            </Link>
                            <button
                              onClick={() => setPendingDelete(s)}
                              className="grid size-8 place-items-center rounded-lg border border-transparent text-mute transition-colors hover:border-clay/40 hover:bg-clay/10 hover:text-clay"
                              title="Delete"
                            >
                              <Trash2 className="size-4" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex items-center justify-between border-t border-line bg-parchment/50 px-4 py-2.5 font-mono text-[11px] uppercase tracking-wider text-mute">
            <span>
              {students.length} record{students.length === 1 ? "" : "s"}
            </span>
            <span className="flex items-center gap-1.5">
              <Download className="size-3.5" /> Excel & ZIP respect current filters
            </span>
          </div>
        </div>
      )}

      {/* Delete confirm */}
      {pendingDelete && (
        <div className="fixed inset-0 z-[100] grid place-items-center bg-ink/60 p-4 backdrop-blur-sm">
          <div className="card w-full max-w-sm p-6">
            <h3 className="text-base font-semibold">Delete this record?</h3>
            <p className="mt-2 text-[13px] leading-relaxed text-mute">
              Serial #{String(pendingDelete.serialNumber).padStart(4, "0")} and its photo{" "}
              <span className="font-mono">{pendingDelete.photoFile}</span> will be permanently
              removed. The serial is retired and never reused.
            </p>
            <div className="mt-5 flex justify-end gap-2">
              <button onClick={() => setPendingDelete(null)} className="btn btn-ghost btn-sm">
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                disabled={deleting}
                className="btn btn-danger btn-sm !bg-clay !text-white !border-clay"
              >
                {deleting ? <Loader2 className="size-3.5 spin" /> : <Trash2 className="size-3.5" />}
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
