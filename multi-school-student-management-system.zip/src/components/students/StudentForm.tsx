"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { toast } from "sonner";
import { CheckCircle2, Loader2, Plus, Save } from "lucide-react";
import { PhotoCapture, type CapturedPhoto } from "@/components/students/PhotoCapture";
import { SerialStamp } from "@/components/ui";
import { formatSerial } from "@/lib/format";

export interface FieldVM {
  id: number;
  label: string;
  fieldKey: string;
  type: "text" | "number" | "date" | "select" | "textarea";
  options: string[];
  required: boolean;
  enabled: boolean;
}

interface StudentInitial {
  id: number;
  serialNumber: number;
  className: string;
  photoFile: string;
  customData: Record<string, string>;
  updatedAt: string | Date;
}

function FieldInput({
  field,
  value,
  onChange,
}: {
  field: FieldVM;
  value: string;
  onChange: (v: string) => void;
}) {
  const common = {
    id: `f-${field.fieldKey}`,
    value,
    required: field.required,
  };
  switch (field.type) {
    case "textarea":
      return (
        <textarea
          {...common}
          className="textarea min-h-[88px]"
          onChange={(e) => onChange(e.target.value)}
        />
      );
    case "select":
      return (
        <select {...common} className="select" onChange={(e) => onChange(e.target.value)}>
          <option value="">Select…</option>
          {field.options.map((o) => (
            <option key={o} value={o}>
              {o}
            </option>
          ))}
        </select>
      );
    case "date":
      return (
        <input
          {...common}
          type="date"
          className="input"
          onChange={(e) => onChange(e.target.value)}
        />
      );
    case "number":
      return (
        <input
          {...common}
          type="text"
          inputMode="numeric"
          pattern="[0-9+ -]*"
          className="input"
          onChange={(e) => onChange(e.target.value.replace(/[^\d+\- ]/g, ""))}
        />
      );
    default:
      return (
        <input
          {...common}
          type="text"
          className="input"
          onChange={(e) => onChange(e.target.value)}
        />
      );
  }
}

export function StudentForm({
  mode,
  initial,
  fields: initialFields,
}: {
  mode: "create" | "edit";
  initial?: StudentInitial;
  fields?: FieldVM[];
}) {
  const router = useRouter();
  const [fields, setFields] = useState<FieldVM[] | null>(initialFields ?? null);
  const [className, setClassName] = useState(initial?.className ?? "");
  const [values, setValues] = useState<Record<string, string>>(
    initial?.customData ?? {},
  );
  const [photo, setPhoto] = useState<CapturedPhoto | null>(null);
  const [busy, setBusy] = useState(false);
  const [createdSerial, setCreatedSerial] = useState<number | null>(null);

  useEffect(() => {
    if (fields) return;
    fetch("/api/fields")
      .then((r) => r.json())
      .then((d) => {
        const list: FieldVM[] = (d.fields ?? []).filter((f: FieldVM) => f.enabled);
        setFields(list);
      })
      .catch(() => toast.error("Could not load form fields."));
  }, [fields]);

  const enabledFields = useMemo(
    () => (fields ?? []).filter((f) => f.enabled),
    [fields],
  );

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    if (mode === "create" && !photo) {
      toast.error("A student photo is mandatory — capture or upload one.");
      return;
    }
    setBusy(true);
    try {
      const fd = new FormData();
      fd.set("className", className);
      fd.set("data", JSON.stringify(values));
      if (photo) fd.set("photo", photo.file);

      const url = mode === "create" ? "/api/students" : `/api/students/${initial!.id}`;
      const res = await fetch(url, { method: mode === "create" ? "POST" : "PATCH", body: fd });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Save failed.");

      if (mode === "create") {
        setCreatedSerial(data.serial);
        toast.success(`Student saved as serial ${formatSerial(data.serial)}`);
      } else {
        toast.success("Student updated");
        router.refresh();
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Save failed.");
    } finally {
      setBusy(false);
    }
  }

  /* ---------- success card after create ---------- */
  if (createdSerial !== null) {
    return (
      <div className="card rise mx-auto max-w-lg px-6 py-12 text-center">
        <span className="mx-auto grid size-16 place-items-center rounded-2xl border border-moss/30 bg-moss/10">
          <CheckCircle2 className="size-8 text-moss" />
        </span>
        <h2 className="mt-5 text-xl font-semibold tracking-tight">Student recorded</h2>
        <p className="mt-2 text-sm text-mute">
          The photo was compressed and renamed to{" "}
          <span className="font-mono font-semibold text-ink">
            {formatSerial(createdSerial)}.jpg
          </span>
        </p>
        <div className="mt-4 flex justify-center">
          <SerialStamp serial={createdSerial} />
        </div>
        <div className="mt-8 flex flex-wrap justify-center gap-2.5">
          <button
            onClick={() => {
              setCreatedSerial(null);
              setValues({});
              setClassName("");
              if (photo) URL.revokeObjectURL(photo.previewUrl);
              setPhoto(null);
              router.refresh();
            }}
            className="btn btn-ink"
          >
            <Plus className="size-4" /> Add another
          </button>
          <Link href="/dashboard/students" className="btn btn-ghost">
            View all students
          </Link>
        </div>
      </div>
    );
  }

  if (!fields) {
    return (
      <div className="card grid place-items-center py-20">
        <Loader2 className="size-6 spin text-mute" />
      </div>
    );
  }

  const existingPhotoUrl = initial
    ? `/api/photos/${initial.photoFile}?v=${new Date(initial.updatedAt).getTime()}`
    : null;

  return (
    <form onSubmit={submit} className="grid gap-6 lg:grid-cols-[380px_1fr]">
      {/* Photo column */}
      <section className="card rise h-fit p-5">
        <p className="label">Photograph</p>
        <PhotoCapture value={photo} onChange={setPhoto} />
        {mode === "edit" && existingPhotoUrl && !photo && (
          <div className="mt-4">
            <p className="label">Current photo</p>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={existingPhotoUrl}
              alt="Current student"
              className="h-44 w-full rounded-xl border border-line object-cover"
            />
          </div>
        )}
        <p className="mt-4 border-t border-line pt-3 text-[11px] leading-relaxed text-mute">
          Photos are compressed in the browser before upload to save storage, then renamed
          to the student&apos;s unique serial number. Serials are never reused.
        </p>
      </section>

      {/* Data column */}
      <section className="card rise rise-1 p-5 sm:p-6">
        <div className="flex items-center justify-between gap-3">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-mute">
            {mode === "create" ? "Student details" : `Editing`}
          </h3>
          {initial && <SerialStamp serial={initial.serialNumber} />}
        </div>

        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="className">
              Class <span className="text-clay">*</span>
            </label>
            <input
              id="className"
              className="input"
              value={className}
              onChange={(e) => setClassName(e.target.value)}
              placeholder='e.g. "Class 6 — A"'
              required
            />
          </div>

          {enabledFields.map((f) => (
            <div key={f.fieldKey} className={f.type === "textarea" ? "sm:col-span-2" : ""}>
              <label className="label" htmlFor={`f-${f.fieldKey}`}>
                {f.label} {f.required && <span className="text-clay">*</span>}
              </label>
              <FieldInput
                field={f}
                value={values[f.fieldKey] ?? ""}
                onChange={(v) => setValues((prev) => ({ ...prev, [f.fieldKey]: v }))}
              />
            </div>
          ))}

          {enabledFields.length === 0 && (
            <p className="sm:col-span-2 rounded-xl border border-amber/30 bg-amber/5 px-4 py-3 text-[13px] text-amber">
              No custom fields yet. Add them under{" "}
              <Link href="/dashboard/fields" className="font-semibold underline">
                Form Fields
              </Link>
              .
            </p>
          )}
        </div>

        <div className="mt-6 flex items-center gap-2.5 border-t border-line pt-5">
          <button type="submit" className="btn btn-primary" disabled={busy}>
            {busy ? (
              <Loader2 className="size-4 spin" />
            ) : mode === "create" ? (
              <Plus className="size-4" />
            ) : (
              <Save className="size-4" />
            )}
            {busy
              ? "Saving…"
              : mode === "create"
                ? "Save student"
                : "Save changes"}
          </button>
          <Link href="/dashboard/students" className="btn btn-ghost">
            Cancel
          </Link>
        </div>
      </section>
    </form>
  );
}
