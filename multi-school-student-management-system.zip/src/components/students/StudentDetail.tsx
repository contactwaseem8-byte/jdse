"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import {
  ArrowLeft,
  CalendarDays,
  Download,
  Loader2,
  PencilLine,
  Trash2,
} from "lucide-react";
import { SerialStamp } from "@/components/ui";
import { StudentForm, type FieldVM } from "@/components/students/StudentForm";
import { formatDate } from "@/lib/format";

export interface StudentVM {
  id: number;
  serialNumber: number;
  className: string;
  photoFile: string;
  customData: Record<string, string>;
  createdAt: string;
  updatedAt: string;
  schoolId: number;
  schoolName: string;
  schoolCode: string;
  createdByName: string | null;
}

export function StudentDetail({
  student,
  fields,
  role,
  startEditing,
}: {
  student: StudentVM;
  fields: FieldVM[];
  role: "super_admin" | "admin" | "school";
  startEditing: boolean;
}) {
  const router = useRouter();
  const [editing, setEditing] = useState(startEditing);
  const [confirming, setConfirming] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const canEdit = role === "school";
  const photoUrl = `/api/photos/${student.photoFile}?v=${new Date(student.updatedAt).getTime()}`;
  const allFields = fields.filter(
    (f) => f.enabled || student.customData[f.fieldKey],
  );

  async function remove() {
    setDeleting(true);
    try {
      const res = await fetch(`/api/students/${student.id}`, { method: "DELETE" });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || "Delete failed");
      toast.success("Record deleted");
      router.replace("/dashboard/students");
      router.refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Delete failed");
      setDeleting(false);
    }
  }

  if (editing) {
    return (
      <>
        <header className="rise mb-7 flex flex-wrap items-end justify-between gap-4">
          <div>
            <Link
              href={`/dashboard/students/${student.id}`}
              onClick={(e) => {
                e.preventDefault();
                setEditing(false);
              }}
              className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.28em] text-mute hover:text-ink"
            >
              <ArrowLeft className="size-3" /> Back to record
            </Link>
            <h1 className="mt-1.5 text-[1.7rem] font-semibold tracking-tight">
              Edit student record
            </h1>
          </div>
          <SerialStamp serial={student.serialNumber} />
        </header>
        <StudentForm
          mode="edit"
          fields={fields}
          initial={{
            id: student.id,
            serialNumber: student.serialNumber,
            className: student.className,
            photoFile: student.photoFile,
            customData: student.customData,
            updatedAt: student.updatedAt,
          }}
        />
      </>
    );
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[400px_1fr]">
      {/* Photo card */}
      <section className="card rise h-fit overflow-hidden">
        <div className="relative">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={photoUrl} alt="Student" className="aspect-[4/5] w-full object-cover" />
          <div className="absolute left-3 top-3">
            <SerialStamp serial={student.serialNumber} />
          </div>
        </div>
        <div className="flex items-center justify-between gap-3 p-4">
          <div className="min-w-0">
            <p className="truncate font-mono text-xs text-mute">{student.photoFile}</p>
            <p className="text-[10px] uppercase tracking-widest text-mute/70">
              serial-stamped file
            </p>
          </div>
          <a href={photoUrl} download={student.photoFile} className="btn btn-ghost btn-sm">
            <Download className="size-3.5" /> Photo
          </a>
        </div>
      </section>

      {/* Data card */}
      <section className="card rise rise-1 h-fit p-6">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <Link
              href="/dashboard/students"
              className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.28em] text-mute hover:text-ink"
            >
              <ArrowLeft className="size-3" /> Registry
            </Link>
            <h1 className="mt-2 text-2xl font-semibold tracking-tight">
              {Object.values(student.customData)[0] || "Student record"}
            </h1>
            <p className="mt-1 font-mono text-xs uppercase tracking-wider text-mute">
              {student.schoolCode} · {student.schoolName} · {student.className}
            </p>
          </div>
          {canEdit && (
            <div className="flex gap-2">
              <button onClick={() => setEditing(true)} className="btn btn-ink btn-sm">
                <PencilLine className="size-3.5" /> Edit
              </button>
              <button onClick={() => setConfirming(true)} className="btn btn-danger btn-sm">
                <Trash2 className="size-3.5" /> Delete
              </button>
            </div>
          )}
        </div>

        <dl className="mt-6 grid gap-x-8 gap-y-4 sm:grid-cols-2">
          <div>
            <dt className="label !mb-1">Class</dt>
            <dd className="text-sm font-medium">{student.className}</dd>
          </div>
          {allFields.map((f) => (
            <div key={f.fieldKey}>
              <dt className="label !mb-1">{f.label}</dt>
              <dd className="text-sm font-medium">
                {student.customData[f.fieldKey] || (
                  <span className="text-mute/60">—</span>
                )}
              </dd>
            </div>
          ))}
        </dl>

        <div className="mt-7 flex flex-wrap items-center gap-x-8 gap-y-2 border-t border-line pt-4 font-mono text-[11px] uppercase tracking-wider text-mute">
          <span className="flex items-center gap-1.5">
            <CalendarDays className="size-3.5" /> Added {formatDate(student.createdAt)}
          </span>
          <span>Updated {formatDate(student.updatedAt)}</span>
          {student.createdByName && <span>By {student.createdByName}</span>}
        </div>
      </section>

      {/* Delete confirm */}
      {confirming && (
        <div className="fixed inset-0 z-[100] grid place-items-center bg-ink/60 p-4 backdrop-blur-sm">
          <div className="card w-full max-w-sm p-6">
            <h3 className="text-base font-semibold">Delete this record?</h3>
            <p className="mt-2 text-[13px] leading-relaxed text-mute">
              The student and photo <span className="font-mono">{student.photoFile}</span>{" "}
              will be permanently removed. Serials are never reused.
            </p>
            <div className="mt-5 flex justify-end gap-2">
              <button onClick={() => setConfirming(false)} className="btn btn-ghost btn-sm">
                Cancel
              </button>
              <button
                onClick={remove}
                disabled={deleting}
                className="btn btn-sm !bg-clay !text-white"
              >
                {deleting ? <Loader2 className="size-3.5 spin" /> : <Trash2 className="size-3.5" />}
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
