"use client";

import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import {
  ArrowDown,
  ArrowUp,
  CalendarDays,
  CheckSquare,
  ChevronDown,
  Hash,
  Loader2,
  PencilLine,
  Plus,
  Save,
  Text,
  TextCursorInput,
  Trash2,
  X,
} from "lucide-react";
import type { FieldVM } from "@/components/students/StudentForm";

const TYPE_META: Record<FieldVM["type"], { label: string; icon: React.ComponentType<{ className?: string }> }> = {
  text: { label: "Short text", icon: TextCursorInput },
  number: { label: "Number", icon: Hash },
  date: { label: "Date", icon: CalendarDays },
  select: { label: "Dropdown", icon: ChevronDown },
  textarea: { label: "Long text", icon: Text },
};

interface FieldRow extends FieldVM {
  sortOrder: number;
}

export function FieldsManager() {
  const [fields, setFields] = useState<FieldRow[] | null>(null);
  const [editing, setEditing] = useState<number | "new" | null>(null);
  const [busy, setBusy] = useState(false);

  // edit buffer
  const [buf, setBuf] = useState({ label: "", type: "text" as FieldVM["type"], options: "", required: false });

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/fields", { cache: "no-store" });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "Load failed");
      setFields(d.fields);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Load failed");
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function patch(id: number, body: Record<string, unknown>) {
    try {
      const res = await fetch(`/api/fields/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || "Save failed");
      return true;
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Save failed");
      return false;
    }
  }

  async function toggle(id: number, key: "enabled" | "required", value: boolean) {
    setFields((prev) => prev?.map((f) => (f.id === id ? { ...f, [key]: value } : f)) ?? null);
    const ok = await patch(id, { [key]: value });
    if (!ok) load();
    else if (key === "enabled") toast(value ? "Field shown on form" : "Field hidden from form");
  }

  async function move(index: number, dir: -1 | 1) {
    if (!fields) return;
    const other = index + dir;
    if (other < 0 || other >= fields.length) return;
    const a = fields[index];
    const b = fields[other];
    const next = [...fields];
    [next[index], next[other]] = [b, a];
    setFields(next);
    await Promise.all([
      patch(a.id, { sortOrder: other }),
      patch(b.id, { sortOrder: index }),
    ]);
  }

  async function save() {
    if (busy) return;
    setBusy(true);
    try {
      if (editing === "new") {
        const res = await fetch("/api/fields", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            label: buf.label,
            type: buf.type,
            required: buf.required,
            options: buf.options.split(",").map((s) => s.trim()).filter(Boolean),
          }),
        });
        const d = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(d.error || "Create failed");
        toast.success("Field added to your form");
      } else if (typeof editing === "number") {
        const ok = await patch(editing, {
          label: buf.label,
          required: buf.required,
          options: buf.options.split(",").map((s) => s.trim()).filter(Boolean),
        });
        if (!ok) return;
        toast.success("Field updated");
      }
      setEditing(null);
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: number) {
    const ok = await fetch(`/api/fields/${id}`, { method: "DELETE" }).then(async (r) => {
      if (!r.ok) {
        const d = await r.json().catch(() => ({}));
        toast.error(d.error || "Delete failed");
        return false;
      }
      return true;
    });
    if (ok) {
      toast.success("Field removed");
      load();
    }
  }

  if (!fields) {
    return (
      <div className="card grid place-items-center py-24">
        <Loader2 className="size-6 spin text-mute" />
      </div>
    );
  }

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
      {/* Field list */}
      <div className="space-y-2.5">
        <div className="mb-3 grid grid-cols-[auto_1fr_auto_auto] items-center gap-3 px-1 font-mono text-[10px] uppercase tracking-[0.18em] text-mute max-lg:hidden">
          <span className="w-14 text-center">Order</span>
          <span>Field</span>
          <span className="w-28 text-center">Type</span>
          <span className="w-40 text-center">Form behavior</span>
        </div>

        {fields.map((f, i) => {
          const Meta = TYPE_META[f.type];
          const isEditing = editing === f.id;
          return (
            <div key={f.id} className={`card rise p-3.5 ${!f.enabled ? "opacity-55" : ""}`}>
              <div className="grid grid-cols-[auto_1fr_auto] items-center gap-3 lg:grid-cols-[auto_1fr_auto_auto]">
                <div className="flex w-14 flex-col items-center gap-0.5">
                  <button
                    onClick={() => move(i, -1)}
                    disabled={i === 0}
                    className="grid size-5 place-items-center rounded text-mute hover:bg-parchment hover:text-ink disabled:opacity-20"
                    aria-label="Move up"
                  >
                    <ArrowUp className="size-3" />
                  </button>
                  <span className="font-mono text-[10px] text-mute">{String(i + 1).padStart(2, "0")}</span>
                  <button
                    onClick={() => move(i, 1)}
                    disabled={i === fields.length - 1}
                    className="grid size-5 place-items-center rounded text-mute hover:bg-parchment hover:text-ink disabled:opacity-20"
                    aria-label="Move down"
                  >
                    <ArrowDown className="size-3" />
                  </button>
                </div>

                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold">{f.label}</p>
                  <p className="truncate font-mono text-[10px] text-mute">
                    {f.fieldKey}
                    {f.type === "select" && f.options.length > 0 && ` · ${f.options.join(", ")}`}
                  </p>
                </div>

                <span className="hidden w-28 items-center justify-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-mute lg:flex">
                  <Meta.icon className="size-3.5" /> {Meta.label}
                </span>

                <div className="flex w-auto items-center justify-end gap-1.5 lg:w-40 lg:justify-center">
                  <button
                    onClick={() => toggle(f.id, "required", !f.required)}
                    className={`rounded-md border px-2 py-1 font-mono text-[10px] font-semibold uppercase tracking-wide transition-colors ${
                      f.required
                        ? "border-cobalt/40 bg-cobalt/10 text-cobalt"
                        : "border-line text-mute hover:border-mute"
                    }`}
                    title="Toggle required"
                  >
                    Required
                  </button>
                  <button
                    onClick={() => toggle(f.id, "enabled", !f.enabled)}
                    className={`rounded-md border px-2 py-1 font-mono text-[10px] font-semibold uppercase tracking-wide transition-colors ${
                      f.enabled
                        ? "border-moss/40 bg-moss/10 text-moss"
                        : "border-line text-mute hover:border-mute"
                    }`}
                    title="Toggle visibility on the form"
                  >
                    {f.enabled ? "Shown" : "Hidden"}
                  </button>
                  <button
                    onClick={() => {
                      setEditing(f.id);
                      setBuf({
                        label: f.label,
                        type: f.type,
                        options: f.options.join(", "),
                        required: f.required,
                      });
                    }}
                    className="grid size-7 place-items-center rounded-lg text-mute hover:bg-parchment hover:text-ink"
                    title="Edit"
                  >
                    <PencilLine className="size-3.5" />
                  </button>
                  <button
                    onClick={() => remove(f.id)}
                    className="grid size-7 place-items-center rounded-lg text-mute hover:bg-clay/10 hover:text-clay"
                    title="Delete"
                  >
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              </div>

              {isEditing && (
                <Editor
                  buf={buf}
                  setBuf={setBuf}
                  onCancel={() => setEditing(null)}
                  onSave={save}
                  busy={busy}
                  isNew={false}
                />
              )}
            </div>
          );
        })}

        {fields.length === 0 && (
          <div className="card grid place-items-center py-14 text-center">
            <p className="text-sm text-mute">No fields yet — build your school's form on the right.</p>
          </div>
        )}
      </div>

      {/* Add field panel */}
      <aside className="card h-fit p-5">
        <h3 className="flex items-center gap-2 text-sm font-semibold">
          <Plus className="size-4 text-cobalt" /> Add a custom field
        </h3>
        <p className="mt-1.5 text-xs leading-relaxed text-mute">
          Design the exact admission form your school needs. Changes apply instantly to
          the Add Student page.
        </p>

        {editing === "new" ? (
          <Editor buf={buf} setBuf={setBuf} onCancel={() => setEditing(null)} onSave={save} busy={busy} isNew />
        ) : (
          <button
            onClick={() => {
              setEditing("new");
              setBuf({ label: "", type: "text", options: "", required: false });
            }}
            className="btn btn-primary mt-4 w-full"
          >
            <Plus className="size-4" /> New field
          </button>
        )}

        <div className="mt-5 space-y-2 border-t border-line pt-4">
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-mute">
            Fixed for every student
          </p>
          {[
            { icon: Hash, label: "Unique serial number", note: "never repeats" },
            { icon: TextCursorInput, label: "Class", note: "for class-wise sorting" },
            { icon: CheckSquare, label: "Photograph", note: "compressed → serial.jpg" },
          ].map((row) => (
            <div key={row.label} className="flex items-center gap-2.5 rounded-lg bg-parchment/60 px-3 py-2">
              <row.icon className="size-3.5 text-mute" />
              <span className="text-xs font-semibold">{row.label}</span>
              <span className="ml-auto font-mono text-[9px] uppercase tracking-wide text-mute/70">
                {row.note}
              </span>
            </div>
          ))}
        </div>
      </aside>
    </div>
  );
}

function Editor({
  buf,
  setBuf,
  onCancel,
  onSave,
  busy,
  isNew,
}: {
  buf: { label: string; type: FieldVM["type"]; options: string; required: boolean };
  setBuf: React.Dispatch<
    React.SetStateAction<{ label: string; type: FieldVM["type"]; options: string; required: boolean }>
  >;
  onCancel: () => void;
  onSave: () => void;
  busy: boolean;
  isNew: boolean;
}) {
  return (
    <div className={`space-y-3 ${isNew ? "mt-4" : "mt-4 border-t border-line pt-4"}`}>
      <div>
        <label className="label">Field label</label>
        <input
          className="input"
          value={buf.label}
          onChange={(e) => setBuf((b) => ({ ...b, label: e.target.value }))}
          placeholder='e.g. "Blood Group"'
        />
      </div>
      {isNew && (
        <div>
          <label className="label">Type</label>
          <select
            className="select"
            value={buf.type}
            onChange={(e) => setBuf((b) => ({ ...b, type: e.target.value as FieldVM["type"] }))}
          >
            {Object.entries(TYPE_META).map(([v, m]) => (
              <option key={v} value={v}>
                {m.label}
              </option>
            ))}
          </select>
        </div>
      )}
      {buf.type === "select" && (
        <div>
          <label className="label">Options (comma separated)</label>
          <input
            className="input"
            value={buf.options}
            onChange={(e) => setBuf((b) => ({ ...b, options: e.target.value }))}
            placeholder="O+, A+, B+, AB+"
          />
        </div>
      )}
      <label className="flex items-center gap-2.5 text-sm font-medium">
        <input
          type="checkbox"
          className="size-4 accent-[#2240d6]"
          checked={buf.required}
          onChange={(e) => setBuf((b) => ({ ...b, required: e.target.checked }))}
        />
        Required on the form
      </label>
      <div className="flex gap-2">
        <button onClick={onSave} disabled={busy || !buf.label.trim()} className="btn btn-primary btn-sm">
          {busy ? <Loader2 className="size-3.5 spin" /> : <Save className="size-3.5" />}
          {isNew ? "Add field" : "Save"}
        </button>
        <button onClick={onCancel} className="btn btn-ghost btn-sm">
          <X className="size-3.5" /> Cancel
        </button>
      </div>
    </div>
  );
}
