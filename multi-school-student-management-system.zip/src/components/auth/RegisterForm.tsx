"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { toast } from "sonner";
import {
  Building2,
  CheckCircle2,
  KeyRound,
  Loader2,
  Send,
  ShieldCheck,
  UserRound,
} from "lucide-react";

interface SchoolOpt {
  id: number;
  name: string;
  code: string;
}

export function RegisterForm({ schools }: { schools: SchoolOpt[] }) {
  const [role, setRole] = useState<"school" | "admin">("school");
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [schoolId, setSchoolId] = useState<string>(schools[0]?.id ? String(schools[0].id) : "");
  const [newSchool, setNewSchool] = useState("");
  const [useNewSchool, setUseNewSchool] = useState(false);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  const schoolInvalid = useMemo(
    () => role === "school" && !useNewSchool && !schoolId,
    [role, useNewSchool, schoolId],
  );

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName,
          username,
          password,
          role,
          schoolId: role === "school" && !useNewSchool ? Number(schoolId) : null,
          requestedSchoolName: role === "school" && useNewSchool ? newSchool : "",
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Registration failed.");
      setDone(true);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Registration failed.");
    } finally {
      setBusy(false);
    }
  }

  if (done) {
    return (
      <div className="text-center">
        <span className="mx-auto grid size-16 place-items-center rounded-2xl border border-moss/30 bg-moss/10">
          <CheckCircle2 className="size-8 text-moss" />
        </span>
        <h2 className="mt-6 text-2xl font-semibold tracking-tight">Request received</h2>
        <p className="mt-3 text-sm leading-relaxed text-mute">
          Your account has been submitted for approval. Once the Super Admin approves it,
          you can sign in with your username and password.
        </p>
        <Link href="/login" className="btn btn-primary w-full mt-8 !py-3">
          Back to sign in
        </Link>
      </div>
    );
  }

  return (
    <div>
      <p className="font-mono text-[10px] tracking-[0.28em] uppercase text-mute">
        New Account
      </p>
      <h2 className="mt-2 text-3xl font-semibold tracking-tight">Request access</h2>
      <p className="mt-2 text-sm text-mute">
        Accounts go live after Super Admin approval.
      </p>

      {/* Role toggle */}
      <div className="mt-6 grid grid-cols-2 gap-2 rounded-xl border border-line bg-parchment/70 p-1.5">
        {(
          [
            { v: "school", label: "School User", icon: Building2 },
            { v: "admin", label: "Administrator", icon: ShieldCheck },
          ] as const
        ).map((opt) => (
          <button
            key={opt.v}
            type="button"
            onClick={() => setRole(opt.v)}
            className={`flex items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-[13px] font-semibold transition-all ${
              role === opt.v
                ? "bg-ink text-cream shadow"
                : "text-mute hover:text-ink"
            }`}
          >
            <opt.icon className="size-4" />
            {opt.label}
          </button>
        ))}
      </div>

      <form onSubmit={submit} className="mt-5 space-y-4">
        <div>
          <label className="label" htmlFor="fullName">
            Full name
          </label>
          <div className="relative">
            <UserRound className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-mute" />
            <input
              id="fullName"
              className="input pl-10"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="e.g. Rakesh Kumar"
              required
            />
          </div>
        </div>

        {role === "school" && (
          <div className="rounded-xl border border-line bg-cream p-4 space-y-3">
            <label className="flex items-center gap-2.5 text-sm font-medium cursor-pointer">
              <input
                type="checkbox"
                checked={useNewSchool}
                onChange={(e) => setUseNewSchool(e.target.checked)}
                className="size-4 accent-[#2240d6]"
              />
              My school is not listed yet
            </label>
            {useNewSchool ? (
              <div>
                <label className="label" htmlFor="newSchool">
                  New school name
                </label>
                <input
                  id="newSchool"
                  className="input"
                  value={newSchool}
                  onChange={(e) => setNewSchool(e.target.value)}
                  placeholder="e.g. Little Scholars Academy"
                  required
                />
              </div>
            ) : (
              <div>
                <label className="label" htmlFor="school">
                  Select school
                </label>
                <select
                  id="school"
                  className="select"
                  value={schoolId}
                  onChange={(e) => setSchoolId(e.target.value)}
                  required={schoolInvalid}
                >
                  <option value="" disabled>
                    Choose a school…
                  </option>
                  {schools.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.code})
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label" htmlFor="reg-username">
              Username
            </label>
            <input
              id="reg-username"
              className="input"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="lowercase"
              autoComplete="username"
              required
            />
          </div>
          <div>
            <label className="label" htmlFor="reg-password">
              Password
            </label>
            <div className="relative">
              <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-mute" />
              <input
                id="reg-password"
                type="password"
                className="input pl-10"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="min 6 chars"
                autoComplete="new-password"
                minLength={6}
                required
              />
            </div>
          </div>
        </div>

        <button className="btn btn-primary w-full !py-3" disabled={busy}>
          {busy ? <Loader2 className="size-4 spin" /> : <Send className="size-4" />}
          {busy ? "Submitting…" : "Submit for approval"}
        </button>
      </form>

      <p className="mt-6 text-sm text-mute">
        Already approved?{" "}
        <Link href="/login" className="font-semibold text-cobalt hover:underline">
          Sign in
        </Link>
      </p>
    </div>
  );
}
