"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { KeyRound, Loader2, LogIn, UserRound } from "lucide-react";

export function LoginForm() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Sign in failed.");
      toast.success(`Welcome back, ${data.user.fullName}`);
      router.replace("/dashboard");
      router.refresh();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Sign in failed.");
      setBusy(false);
    }
  }

  return (
    <div>
      <div className="lg:hidden mb-8 flex items-center gap-3">
        <span className="grid size-10 place-items-center rounded-xl bg-cobalt text-white font-mono font-semibold">
          EV
        </span>
        <span className="text-lg font-semibold tracking-tight">EduVault</span>
      </div>

      <p className="font-mono text-[10px] tracking-[0.28em] uppercase text-mute">
        Secure Access
      </p>
      <h2 className="mt-2 text-3xl font-semibold tracking-tight">Sign in</h2>
      <p className="mt-2 text-sm text-mute">
        Super Admin, Admin and School accounts sign in here.
      </p>

      <form onSubmit={submit} className="mt-8 space-y-4">
        <div>
          <label className="label" htmlFor="username">
            Username
          </label>
          <div className="relative">
            <UserRound className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-mute" />
            <input
              id="username"
              className="input pl-10"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="e.g. sunrise"
              autoComplete="username"
              required
            />
          </div>
        </div>
        <div>
          <label className="label" htmlFor="password">
            Password
          </label>
          <div className="relative">
            <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-mute" />
            <input
              id="password"
              type="password"
              className="input pl-10"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              autoComplete="current-password"
              required
            />
          </div>
        </div>
        <button className="btn btn-primary w-full !py-3" disabled={busy}>
          {busy ? <Loader2 className="size-4 spin" /> : <LogIn className="size-4" />}
          {busy ? "Signing in…" : "Sign in"}
        </button>
      </form>

      <div className="mt-6 rounded-xl border border-line bg-parchment/60 p-4">
        <p className="text-[11px] font-semibold uppercase tracking-wider text-mute">
          Demo credentials
        </p>
        <div className="mt-2 space-y-1 font-mono text-xs text-ink/80">
          <p>superadmin / Super@123</p>
          <p>admin / Admin@123</p>
          <p>sunrise / School@123</p>
        </div>
      </div>

      <p className="mt-6 text-sm text-mute">
        New school or administrator?{" "}
        <Link href="/register" className="font-semibold text-cobalt hover:underline">
          Request an account
        </Link>
      </p>
    </div>
  );
}
