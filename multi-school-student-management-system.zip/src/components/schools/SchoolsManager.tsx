"use client";

import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import {
  Building2,
  Loader2,
  PencilLine,
  Plus,
  Save,
  School as SchoolIcon,
  Trash2,
  Users,
  X,
} from "lucide-react";

interface SchoolRow {
  id: number;
  name: string;
  code: string;
  address: string | null;
  contactPhone: string | null;
  studentCount: number;
  userCount: number;
}

export function SchoolsManager() {
  const [schools, setSchools] = useState<SchoolRow[] | null>(null);
  const [creating, setCreating] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [buf, setBuf] = useState({ name: "", code: "", address: "", contactPhone: "" });

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/schools", { cache: "no-store" });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "Load failed");
      setSchools(d.schools);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Load failed");
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function create() {
    if (busy) return;
    setBusy(true);
    try {
      const res = await fetch("/api/schools", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(buf),
      });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || "Create failed");
      toast.success(`School added with ${7} default form fields`);
      setCreating(false);
      setBuf({ name: "", code: "", address: "", contactPhone: "" });
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Create failed");
    } finally {
      setBusy(false);
    }
  }

  async function saveEdit(id: number) {
    if (busy) return;
    setBusy(true);
    try {
      const res = await fetch(`/api/schools/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: buf.name,
          address: buf.address,
          contactPhone: buf.contactPhone,
        }),
      });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || "Save failed");
      toast.success("School updated");
      setEditingId(null);
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: number) {
    setBusy(true);
    try {
      const res = await fetch(`/api/schools/${id}`, { method: "DELETE" });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || "Delete failed");
      toast.success("School and its records deleted");
      setDeletingId(null);
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Delete failed");
    } finally {
      setBusy(false);
    }
  }

  if (!schools) {
    return (
      <div className="card grid place-items-center py-24">
        <Loader2 className="size-6 spin text-mute" />
      </div>
    );
  }

  return (
    <div className="rise rise-1">
      <div className="mb-4 flex justify-end">
        <button
          onClick={() => {
            setCreating(true);
            setBuf({ name: "", code: "", address: "", contactPhone: "" });
          }}
          className="btn btn-primary"
        >
          <Plus className="size-4" /> Add school
        </button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {schools.map((s) => (
          <article key={s.id} className="card card-hover p-5">
            <div className="flex items-start justify-between gap-3">
              <span className="grid size-10 place-items-center rounded-xl border border-line bg-parchment/70 text-mute">
                <Building2 className="size-[18px]" />
              </span>
              <span className="stamp text-ink/70">{s.code}</span>
            </div>

            {editingId === s.id ? (
              <div className="mt-4 space-y-2.5">
                <input
                  className="input"
                  value={buf.name}
                  onChange={(e) => setBuf((b) => ({ ...b, name: e.target.value }))}
                  placeholder="School name"
                />
                <input
                  className="input"
                  value={buf.address}
                  onChange={(e) => setBuf((b) => ({ ...b, address: e.target.value }))}
                  placeholder="Address"
                />
                <input
                  className="input"
                  value={buf.contactPhone}
                  onChange={(e) => setBuf((b) => ({ ...b, contactPhone: e.target.value }))}
                  placeholder="Contact phone"
                />
                <div className="flex gap-2 pt-1">
                  <button onClick={() => saveEdit(s.id)} disabled={busy} className="btn btn-primary btn-sm">
                    {busy ? <Loader2 className="size-3.5 spin" /> : <Save className="size-3.5" />} Save
                  </button>
                  <button onClick={() => setEditingId(null)} className="btn btn-ghost btn-sm">
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <>
                <h3 className="mt-4 text-[15px] font-semibold leading-snug">{s.name}</h3>
                <p className="mt-1 min-h-[16px] truncate text-xs text-mute">
                  {s.address || "—"}
                </p>
                <div className="mt-4 flex items-center gap-4 border-t border-line pt-3.5 font-mono text-[11px] uppercase tracking-wider text-mute">
                  <span className="flex items-center gap-1.5">
                    <SchoolIcon className="size-3.5" /> {s.studentCount} students
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Users className="size-3.5" /> {s.userCount} users
                  </span>
                  <span className="ml-auto flex gap-1">
                    <button
                      onClick={() => {
                        setEditingId(s.id);
                        setBuf({
                          name: s.name,
                          code: s.code,
                          address: s.address ?? "",
                          contactPhone: s.contactPhone ?? "",
                        });
                      }}
                      className="grid size-7 place-items-center rounded-lg text-mute hover:bg-parchment hover:text-ink"
                      title="Edit"
                    >
                      <PencilLine className="size-3.5" />
                    </button>
                    <button
                      onClick={() => setDeletingId(s.id)}
                      className="grid size-7 place-items-center rounded-lg text-mute hover:bg-clay/10 hover:text-clay"
                      title="Delete"
                    >
                      <Trash2 className="size-3.5" />
                    </button>
                  </span>
                </div>
              </>
            )}

            {deletingId === s.id && (
              <div className="mt-4 rounded-xl border border-clay/30 bg-clay/5 p-3.5">
                <p className="text-xs leading-relaxed text-clay">
                  Delete <strong>{s.name}</strong> and ALL its students, photos and fields?
                </p>
                <div className="mt-3 flex gap-2">
                  <button
                    onClick={() => remove(s.id)}
                    disabled={busy}
                    className="btn btn-sm !bg-clay !text-white"
                  >
                    {busy ? <Loader2 className="size-3.5 spin" /> : <Trash2 className="size-3.5" />} Delete
                  </button>
                  <button onClick={() => setDeletingId(null)} className="btn btn-ghost btn-sm">
                    Keep
                  </button>
                </div>
              </div>
            )}
          </article>
        ))}
      </div>

      {/* Create modal */}
      {creating && (
        <div className="fixed inset-0 z-[100] grid place-items-center bg-ink/60 p-4 backdrop-blur-sm">
          <div className="card w-full max-w-md p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-semibold">Add a school</h3>
              <button
                onClick={() => setCreating(false)}
                className="grid size-8 place-items-center rounded-lg text-mute hover:bg-parchment hover:text-ink"
                aria-label="Close"
              >
                <X className="size-4" />
              </button>
            </div>
            <div className="mt-4 space-y-3">
              <div>
                <label className="label">School name</label>
                <input
                  className="input"
                  value={buf.name}
                  onChange={(e) => setBuf((b) => ({ ...b, name: e.target.value }))}
                  placeholder="e.g. St. Mary's Convent School"
                />
              </div>
              <div>
                <label className="label">Short code</label>
                <input
                  className="input font-mono uppercase"
                  value={buf.code}
                  onChange={(e) =>
                    setBuf((b) => ({ ...b, code: e.target.value.toUpperCase() }))
                  }
                  placeholder="e.g. STM-02"
                  maxLength={20}
                />
                <p className="mt-1 text-[11px] text-mute">
                  Used in ZIP exports — photos are grouped under this code.
                </p>
              </div>
              <div>
                <label className="label">Address</label>
                <input
                  className="input"
                  value={buf.address}
                  onChange={(e) => setBuf((b) => ({ ...b, address: e.target.value }))}
                  placeholder="Street, City"
                />
              </div>
              <div>
                <label className="label">Contact phone</label>
                <input
                  className="input"
                  value={buf.contactPhone}
                  onChange={(e) => setBuf((b) => ({ ...b, contactPhone: e.target.value }))}
                  placeholder="+91 …"
                />
              </div>
            </div>
            <div className="mt-5 flex justify-end gap-2">
              <button onClick={() => setCreating(false)} className="btn btn-ghost">
                Cancel
              </button>
              <button
                onClick={create}
                disabled={busy || !buf.name.trim() || !buf.code.trim()}
                className="btn btn-primary"
              >
                {busy ? <Loader2 className="size-4 spin" /> : <Plus className="size-4" />}
                Create school
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
