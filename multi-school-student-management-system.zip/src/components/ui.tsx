import type { ReactNode } from "react";
import { Inbox } from "lucide-react";
import { formatSerial } from "@/lib/format";

export function PageHeader({
  kicker,
  title,
  description,
  actions,
}: {
  kicker: string;
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <header className="rise mb-7 flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-mute">
          {kicker}
        </p>
        <h1 className="mt-1.5 text-[1.7rem] font-semibold leading-tight tracking-tight">
          {title}
        </h1>
        {description && <p className="mt-1.5 max-w-xl text-sm text-mute">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2.5">{actions}</div>}
    </header>
  );
}

export function SerialStamp({ serial }: { serial: number }) {
  return <span className="stamp text-cobalt">#{formatSerial(serial)}</span>;
}

export function StatusPill({ status }: { status: string }) {
  const cls =
    status === "approved"
      ? "pill-green"
      : status === "pending"
        ? "pill-amber"
        : status === "rejected"
          ? "pill-red"
          : "pill-blue";
  return <span className={`pill ${cls}`}>{status.replace("_", " ")}</span>;
}

export function RolePill({ role }: { role: string }) {
  return <span className="pill pill-blue">{role.replace("_", " ")}</span>;
}

export function EmptyState({
  title,
  description,
  action,
  icon,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
  icon?: ReactNode;
}) {
  return (
    <div className="card grid place-items-center px-6 py-16 text-center">
      <span className="grid size-14 place-items-center rounded-2xl border border-line bg-parchment/70 text-mute">
        {icon ?? <Inbox className="size-6" />}
      </span>
      <h3 className="mt-4 text-base font-semibold">{title}</h3>
      {description && (
        <p className="mx-auto mt-1.5 max-w-sm text-[13px] leading-relaxed text-mute">
          {description}
        </p>
      )}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}
