"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  Building2,
  CheckCircle2,
  Loader2,
  Plus,
  ShieldCheck,
  Trash2,
  UserPlus,
  UserRoundCheck,
  UserRoundX,
  X,
} from "lucide-react";
import { RolePill, StatusPill } from "@/components/ui";

interface UserRow {
  id: number;
  username: string;
  fullName: string;
  role: "super_admin" | "admin" | "school";
  status: "pending" | "approved" | "rejected";
  schoolName: string | null;
  requestedSchoolName: string | null;
  createdAt: string;
}

interface SchoolOpt {
  id: number;
  name: string;
  code: string;
}

export function UsersManager({ schools }: { schools: SchoolOpt[] }) {
  const [users, setUsers] = useState<UserRow[] | null>(null);
  const [tab, setTab] = useState<"pending" | "all">("all");
  const [creating, setCreating] = useState(false);
  const [busy, setBusy] = useState(false);
  const [busyId, setBusyId] = useState<number | null>(null);
  const [form, setForm] = useState({
    fullName: "",
    username: "",
    password: "",
    role: "school" as "school" | "admin",
    schoolId: schools[0] ? String(schools[0].id) : "",
  });

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/users", { cache: "no-store" });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "Load failed");
      setUsers(d.users);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Load failed");
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const pending = useMemo(() => (users ?? []).filter((u) => u.status === "pending"), [users]);
  const visible = tab === "pending" ? pending : (users ?? []);

  async function setStatus(id: number, status: "approved" | "rejected") {
    setBusyId(id);
    try {
      const res = await fetch(`/api/users/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || "Action failed");
      toast.success(
        status === "approved"
          ? "Approved — they can sign in now"
          : "Registration rejected",
      );
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Action failed");
    } finally {
      setBusyId(null);
    }
  }

  async function remove(id: number) {
    setBusyId(id);
    try {
      const res = await fetch(`/api/users/${id}`, { method: "DELETE" });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || "Delete failed");
      toast.success("Account deleted");
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Delete failed");
    } finally {
      setBusyId(null);
    }
  }

  async function create() {
    if (busy) return;
    setBusy(true);
    try {
      const res = await fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          schoolId: form.role === "school" ? Number(form.schoolId) : null,
        }),
      });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || "Create failed");
      toast.success("Account created (pre-approved)");
      setCreating(false);
      setForm({
        fullName: "",
        username: "",
        password: "",
        role: "school",
        schoolId: schools[0] ? String(schools[0].id) : "",
      });
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Create failed");
    } finally {
      setBusy(false);
    }
  }

  if (!users) {
    return (
      <div className="card grid place-items-center py-24">
        <Loader2 className="size-6 spin text-mute" />
      </div>
    );
  }

  return (
    <div className="rise rise-1">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex gap-1 rounded-xl border border-line bg-cream p-1">
          <button
            onClick={() => setTab("all")}
            className={`rounded-lg px-4 py-1.5 text-[13px] font-semibold transition-colors ${
              tab === "all" ? "bg-ink text-cream" : "text-mute hover:text-ink"
            }`}
          >
            All accounts ({users.length})
          </button>
          <button
            onClick={() => setTab("pending")}
            className={`flex items-center gap-1.5 rounded-lg px-4 py-1.5 text-[13px] font-semibold transition-colors ${
              tab === "pending" ? "bg-amber text-white" : "text-mute hover:text-ink"
            }`}
          >
            Pending
            {pending.length > 0 && (
              <span className="grid size-5 place-items-center rounded-full bg-clay font-mono text-[10px] text-white">
                {pending.length}
              </span>
            )}
          </button>
        </div>
        <button onClick={() => setCreating(true)} className="btn btn-primary">
          <UserPlus className="size-4" /> Create account
        </button>
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="data-table">
            <thead>
              <tr>
                <th>User</th>
                <th>Role</th>
                <th>School</th>
                <th>Status</th>
                <th className="!text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((u) => (
                <tr key={u.id}>
                  <td>
                    <p className="font-semibold">{u.fullName}</p>
                    <p className="font-mono text-[11px] text-mute">@{u.username}</p>
                  </td>
                  <td>
                    <RolePill role={u.role} />
                  </td>
                  <td className="max-w-[220px] truncate text-ink/85">
                    {u.role === "school"
                      ? (u.schoolName ?? (
                          <span className="text-amber">
                            {u.requestedSchoolName
                              ? `New: ${u.requestedSchoolName}`
                              : "Unassigned"}
                          </span>
                        ))
                      : "—"}
                  </td>
                  <td>
                    <StatusPill status={u.status} />
                  </td>
                  <td>
                    <div className="flex items-center justify-end gap-1">
                      {busyId === u.id ? (
                        <Loader2 className="size-4 spin text-mute" />
                      ) : (
                        <>
                          {u.status !== "approved" && (
                            <button
                              onClick={() => setStatus(u.id, "approved")}
                              className="grid size-8 place-items-center rounded-lg text-moss transition-colors hover:bg-moss/10"
                              title="Approve"
                            >
                              <UserRoundCheck className="size-4" />
                            </button>
                          )}
                          {u.status === "pending" && (
                            <button
                              onClick={() => setStatus(u.id, "rejected")}
                              className="grid size-8 place-items-center rounded-lg text-amber transition-colors hover:bg-amber/10"
                              title="Reject"
                            >
                              <UserRoundX className="size-4" />
                            </button>
                          )}
                          <button
                            onClick={() => remove(u.id)}
                            className="grid size-8 place-items-center rounded-lg text-mute transition-colors hover:bg-clay/10 hover:text-clay"
                            title="Delete account"
                          >
                            <Trash2 className="size-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {visible.length === 0 && (
                <tr>
                  <td colSpan={5} className="!py-14 text-center">
                    <CheckCircle2 className="mx-auto size-6 text-moss" />
                    <p className="mt-2 text-sm text-mute">
                      {tab === "pending" ? "No pending requests — all caught up." : "No accounts."}
                    </p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create modal */}
      {creating && (
        <div className="fixed inset-0 z-[100] grid place-items-center bg-ink/60 p-4 backdrop-blur-sm">
          <div className="card w-full max-w-md p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-semibold">Create an account</h3>
              <button
                onClick={() => setCreating(false)}
                className="grid size-8 place-items-center rounded-lg text-mute hover:bg-parchment hover:text-ink"
                aria-label="Close"
              >
                <X className="size-4" />
              </button>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-2 rounded-xl border border-line bg-parchment/70 p-1.5">
              {(
                [
                  { v: "school", label: "School User", icon: Building2 },
                  { v: "admin", label: "Admin", icon: ShieldCheck },
                ] as const
              ).map((opt) => (
                <button
                  key={opt.v}
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, role: opt.v }))}
                  className={`flex items-center justify-center gap-2 rounded-lg px-3 py-2 text-[13px] font-semibold transition-all ${
                    form.role === opt.v ? "bg-ink text-cream shadow" : "text-mute hover:text-ink"
                  }`}
                >
                  <opt.icon className="size-4" /> {opt.label}
                </button>
              ))}
            </div>

            <div className="mt-4 space-y-3">
              <input
                className="input"
                placeholder="Full name"
                value={form.fullName}
                onChange={(e) => setForm((f) => ({ ...f, fullName: e.target.value }))}
              />
              {form.role === "school" && (
                <select
                  className="select"
                  value={form.schoolId}
                  onChange={(e) => setForm((f) => ({ ...f, schoolId: e.target.value }))}
                >
                  {schools.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.code})
                    </option>
                  ))}
                </select>
              )}
              <div className="grid grid-cols-2 gap-3">
                <input
                  className="input"
                  placeholder="Username"
                  value={form.username}
                  onChange={(e) => setForm((f) => ({ ...f, username: e.target.value }))}
                />
                <input
                  className="input"
                  type="password"
                  placeholder="Password (min 6)"
                  value={form.password}
                  onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
                />
              </div>
            </div>

            <div className="mt-5 flex justify-end gap-2">
              <button onClick={() => setCreating(false)} className="btn btn-ghost">
                Cancel
              </button>
              <button
                onClick={create}
                disabled={
                  busy ||
                  !form.fullName.trim() ||
                  !form.username.trim() ||
                  form.password.length < 6 ||
                  (form.role === "school" && !form.schoolId)
                }
                className="btn btn-primary"
              >
                {busy ? <Loader2 className="size-4 spin" /> : <Plus className="size-4" />}
                Create
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
