import { db } from "@/db";
import { counters, fieldDefinitions, schools, students, users } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { eq } from "drizzle-orm";
import path from "path";
import { promises as fs } from "fs";

/** Default fields every new school starts with (fully customizable afterwards). */
export const DEFAULT_FIELDS: Array<{
  label: string;
  key: string;
  type: "text" | "number" | "date" | "select" | "textarea";
  options?: string[];
  required?: boolean;
}> = [
  { label: "Full Name", key: "full_name", type: "text", required: true },
  { label: "Father's Name", key: "father_name", type: "text", required: true },
  { label: "Mother's Name", key: "mother_name", type: "text" },
  { label: "Date of Birth", key: "dob", type: "date", required: true },
  { label: "Gender", key: "gender", type: "select", options: ["Male", "Female", "Other"] },
  { label: "Father's Mobile", key: "father_mobile", type: "number" },
  { label: "Address", key: "address", type: "textarea" },
];

export async function seedDefaultFields(schoolId: number) {
  await db.insert(fieldDefinitions).values(
    DEFAULT_FIELDS.map((f, i) => ({
      schoolId,
      label: f.label,
      fieldKey: f.key,
      type: f.type,
      options: f.options ?? [],
      required: f.required ?? false,
      enabled: true,
      sortOrder: i,
    })),
  );
}

async function createUser(
  username: string,
  password: string,
  fullName: string,
  role: "super_admin" | "admin" | "school",
  schoolId: number | null,
) {
  const existing = await db.select().from(users).where(eq(users.username, username));
  if (existing.length > 0) return existing[0];
  const [u] = await db
    .insert(users)
    .values({
      username,
      passwordHash: await hashPassword(password),
      fullName,
      role,
      status: "approved",
      schoolId,
    })
    .returning();
  return u;
}

/**
 * Idempotent bootstrap: runs at server start via instrumentation.ts.
 * Creates the built-in super admin, a demo admin, a demo school + school user.
 */
export async function ensureSeed() {
  const [superAdmin] = await db
    .select()
    .from(users)
    .where(eq(users.username, "superadmin"));
  if (superAdmin) return; // already seeded

  console.log("[seed] Bootstrapping EduVault demo data…");

  await createUser("superadmin", "Super@123", "Platform Super Admin", "super_admin", null);
  await createUser("admin", "Admin@123", "District Administrator", "admin", null);

  const [sunrise] = await db
    .insert(schools)
    .values({
      name: "Sunrise Public School",
      code: "SUN-01",
      address: "14, Gandhi Marg, Jaipur, Rajasthan",
      contactPhone: "+91 98290 11223",
    })
    .returning();

  await seedDefaultFields(sunrise.id);
  await createUser("sunrise", "School@123", "Sunrise Office", "school", sunrise.id);

  // Seed three demo students whose photos live in uploads/0001.jpg … 0003.jpg
  const seedDir = path.join(process.cwd(), "uploads");
  const demo: Array<{
    serial: number;
    className: string;
    data: Record<string, string>;
  }> = [
    {
      serial: 1,
      className: "Class 6 — A",
      data: {
        full_name: "Aarav Sharma",
        father_name: "Rohit Sharma",
        mother_name: "Nisha Sharma",
        dob: "2014-03-12",
        gender: "Male",
        father_mobile: "9829011223",
        address: "22, Malviya Nagar, Jaipur",
      },
    },
    {
      serial: 2,
      className: "Class 6 — A",
      data: {
        full_name: "Diya Verma",
        father_name: "Manoj Verma",
        mother_name: "Pooja Verma",
        dob: "2014-07-01",
        gender: "Female",
        father_mobile: "9988776655",
        address: "8, Vaishali Nagar, Jaipur",
      },
    },
    {
      serial: 3,
      className: "Class 8 — B",
      data: {
        full_name: "Kabir Singh",
        father_name: "Harpreet Singh",
        mother_name: "Simran Kaur",
        dob: "2012-11-19",
        gender: "Male",
        father_mobile: "9112233445",
        address: "5, Civil Lines, Jaipur",
      },
    },
  ];

  let seededPhotos = 0;
  for (const s of demo) {
    const fileName = `${String(s.serial).padStart(4, "0")}.jpg`;
    try {
      await fs.access(path.join(seedDir, fileName));
      await db.insert(students).values({
        schoolId: sunrise.id,
        serialNumber: s.serial,
        className: s.className,
        photoFile: fileName,
        customData: s.data,
      });
      seededPhotos++;
    } catch {
      /* photo missing — skip that demo row */
    }
  }

  await db
    .insert(counters)
    .values({ id: "student_serial", value: seededPhotos })
    .onConflictDoUpdate({
      target: counters.id,
      set: { value: seededPhotos },
    });

  console.log(`[seed] Done. Demo students seeded: ${seededPhotos}`);
}
