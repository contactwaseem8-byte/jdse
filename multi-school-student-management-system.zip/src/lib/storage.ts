import path from "path";
import { promises as fs } from "fs";

const UPLOAD_DIR = path.join(process.cwd(), "uploads");

export async function ensureUploadDir() {
  await fs.mkdir(UPLOAD_DIR, { recursive: true });
  return UPLOAD_DIR;
}

export async function savePhoto(fileName: string, data: Buffer) {
  const dir = await ensureUploadDir();
  await fs.writeFile(path.join(dir, fileName), data);
}

export async function readPhoto(fileName: string): Promise<Buffer | null> {
  try {
    const dir = await ensureUploadDir();
    return await fs.readFile(path.join(dir, fileName));
  } catch {
    return null;
  }
}

export async function deletePhoto(fileName: string) {
  try {
    const dir = await ensureUploadDir();
    await fs.unlink(path.join(dir, fileName));
  } catch {
    /* already gone */
  }
}

export async function uploadStats() {
  try {
    const dir = await ensureUploadDir();
    const files = await fs.readdir(dir);
    let bytes = 0;
    for (const f of files) {
      const s = await fs.stat(path.join(dir, f));
      bytes += s.size;
    }
    return { count: files.length, bytes };
  } catch {
    return { count: 0, bytes: 0 };
  }
}
