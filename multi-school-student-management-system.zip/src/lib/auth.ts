import { SignJWT, jwtVerify } from "jose";
import bcrypt from "bcryptjs";
import { cookies } from "next/headers";
import type { UserRole } from "@/db/schema";

const COOKIE_NAME = "eduvault_session";
const SESSION_DAYS = 7;

function getSecret() {
  const raw =
    process.env.SESSION_SECRET ||
    "eduvault-dev-secret-please-override-in-production-0123456789";
  return new TextEncoder().encode(raw);
}

export interface SessionPayload {
  uid: number;
  username: string;
  fullName: string;
  role: UserRole;
  schoolId: number | null;
}

export async function hashPassword(password: string) {
  return bcrypt.hash(password, 10);
}

export async function verifyPassword(password: string, hash: string) {
  return bcrypt.compare(password, hash);
}

export async function createSession(payload: SessionPayload) {
  const token = await new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_DAYS}d`)
    .sign(getSecret());

  const store = await cookies();
  store.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * SESSION_DAYS,
  });
}

export async function getSession(): Promise<SessionPayload | null> {
  const store = await cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, getSecret());
    return {
      uid: Number(payload.uid),
      username: String(payload.username),
      fullName: String(payload.fullName),
      role: payload.role as UserRole,
      schoolId: payload.schoolId === null || payload.schoolId === undefined ? null : Number(payload.schoolId),
    };
  } catch {
    return null;
  }
}

export async function destroySession() {
  const store = await cookies();
  store.delete(COOKIE_NAME);
}

export function dashboardPathFor(role: UserRole) {
  switch (role) {
    case "super_admin":
      return "/dashboard/users";
    case "admin":
      return "/dashboard/students";
    case "school":
      return "/dashboard/students";
  }
}
