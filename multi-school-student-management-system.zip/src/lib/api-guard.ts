import { NextResponse } from "next/server";
import { getSession, type SessionPayload } from "@/lib/auth";
import type { UserRole } from "@/db/schema";

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export async function requireAuth(allowed?: UserRole[]): Promise<SessionPayload> {
  const session = await getSession();
  if (!session) throw new ApiError(401, "You must be signed in.");
  if (allowed && !allowed.includes(session.role)) {
    throw new ApiError(403, "You do not have permission to perform this action.");
  }
  return session;
}

/** A school-scoped session: must be a school user tied to a school. */
export async function requireSchool(session: SessionPayload): Promise<number> {
  if (session.role !== "school" || !session.schoolId) {
    throw new ApiError(403, "This action requires a school account linked to a school.");
  }
  return session.schoolId;
}

export function apiError(err: unknown) {
  if (err instanceof ApiError) {
    return NextResponse.json({ error: err.message }, { status: err.status });
  }
  console.error("[api]", err);
  return NextResponse.json(
    { error: "Something went wrong on the server." },
    { status: 500 },
  );
}

export function sanitizeUsername(raw: string) {
  return raw.toLowerCase().replace(/[^a-z0-9._-]/g, "").slice(0, 40);
}

export { formatSerial } from "@/lib/format";
