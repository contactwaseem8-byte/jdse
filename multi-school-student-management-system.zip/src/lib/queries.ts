import { db } from "@/db";
import { counters, fieldDefinitions, schools, students, users } from "@/db/schema";
import { and, asc, desc, eq, ilike, inArray, or, sql, type SQL } from "drizzle-orm";

/** Atomically allocate the next globally-unique student serial number. */
export async function allocateSerial(): Promise<number> {
  const [row] = await db
    .insert(counters)
    .values({ id: "student_serial", value: 1 })
    .onConflictDoUpdate({
      target: counters.id,
      set: { value: sql`${counters.value} + 1` },
    })
    .returning({ value: counters.value });
  return row.value;
}

export interface StudentFilter {
  schoolId?: number;
  className?: string;
  q?: string;
  sort?: "serial_asc" | "serial_desc" | "class_asc" | "newest";
  limit?: number;
}

export interface StudentRow {
  id: number;
  serialNumber: number;
  className: string;
  photoFile: string;
  customData: Record<string, string>;
  createdAt: Date;
  updatedAt: Date;
  schoolId: number;
  schoolName: string;
  schoolCode: string;
  createdByName: string | null;
}

export async function fetchStudents(filter: StudentFilter): Promise<StudentRow[]> {
  const conds: SQL[] = [];
  if (filter.schoolId) conds.push(eq(students.schoolId, filter.schoolId));
  if (filter.className) conds.push(eq(students.className, filter.className));
  if (filter.q) {
    const q = filter.q.trim();
    const like = `%${q}%`;
    const serialNum = /^\d+$/.test(q) ? parseInt(q, 10) : null;
    const clauses: SQL[] = [
      ilike(sql`cast(${students.customData} as text)`, like),
      ilike(students.className, like),
    ];
    if (serialNum !== null) clauses.push(eq(students.serialNumber, serialNum));
    const combined = or(...clauses);
    if (combined) conds.push(combined);
  }

  const where = conds.length ? and(...conds) : undefined;
  const orderBy =
    filter.sort === "serial_desc"
      ? [desc(students.serialNumber)]
      : filter.sort === "class_asc"
        ? [asc(students.className), asc(students.serialNumber)]
        : filter.sort === "newest"
          ? [desc(students.createdAt)]
          : [asc(students.serialNumber)];

  return db
    .select({
      id: students.id,
      serialNumber: students.serialNumber,
      className: students.className,
      photoFile: students.photoFile,
      customData: students.customData,
      createdAt: students.createdAt,
      updatedAt: students.updatedAt,
      schoolId: students.schoolId,
      schoolName: schools.name,
      schoolCode: schools.code,
      createdByName: users.fullName,
    })
    .from(students)
    .innerJoin(schools, eq(students.schoolId, schools.id))
    .leftJoin(users, eq(students.createdBy, users.id))
    .where(where)
    .orderBy(...orderBy)
    .limit(filter.limit ?? 2000);
}

export type FieldDef = typeof fieldDefinitions.$inferSelect;

/** Enabled fields per school, ordered. */
export async function getFieldMap(schoolIds: number[]): Promise<Map<number, FieldDef[]>> {
  const map = new Map<number, FieldDef[]>();
  if (!schoolIds.length) return map;
  const rows = await db
    .select()
    .from(fieldDefinitions)
    .where(and(inArray(fieldDefinitions.schoolId, schoolIds), eq(fieldDefinitions.enabled, true)))
    .orderBy(asc(fieldDefinitions.sortOrder), asc(fieldDefinitions.id));
  for (const r of rows) {
    if (!map.has(r.schoolId)) map.set(r.schoolId, []);
    map.get(r.schoolId)!.push(r);
  }
  return map;
}

/** All distinct class names visible to the given scope. */
export async function getClasses(schoolId?: number): Promise<string[]> {
  const rows = await db
    .selectDistinct({ className: students.className })
    .from(students)
    .where(schoolId ? eq(students.schoolId, schoolId) : undefined)
    .orderBy(asc(students.className));
  return rows.map((r) => r.className);
}
