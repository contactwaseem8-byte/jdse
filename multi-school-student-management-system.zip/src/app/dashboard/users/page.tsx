import { redirect } from "next/navigation";
import { db } from "@/db";
import { schools } from "@/db/schema";
import { asc } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { PageHeader } from "@/components/ui";
import { UsersManager } from "@/components/users/UsersManager";

export const metadata = { title: "Users · EduVault" };

export default async function UsersPage() {
  const session = await getSession();
  if (!session) redirect("/login");
  if (session.role !== "super_admin") redirect("/dashboard");

  const allSchools = await db
    .select({ id: schools.id, name: schools.name, code: schools.code })
    .from(schools)
    .orderBy(asc(schools.name));

  return (
    <>
      <PageHeader
        kicker="Access Control"
        title="Users & approvals"
        description="Approve registration requests, or create Admin and School accounts directly. Accounts you create are pre-approved and can sign in immediately."
      />
      <UsersManager schools={allSchools} />
    </>
  );
}
