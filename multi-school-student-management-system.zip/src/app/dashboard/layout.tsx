import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { schools, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { DashboardShell } from "@/components/dashboard/DashboardShell";

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const session = await getSession();
  if (!session) redirect("/login");

  // Always read live status so a rejected/deleted user is bounced immediately.
  const [user] = await db.select().from(users).where(eq(users.id, session.uid));
  if (!user || user.status !== "approved") redirect("/login");

  let schoolName: string | null = null;
  let schoolCode: string | null = null;
  if (session.schoolId) {
    const [s] = await db.select().from(schools).where(eq(schools.id, session.schoolId));
    schoolName = s?.name ?? null;
    schoolCode = s?.code ?? null;
  }

  return (
    <DashboardShell
      role={user.role}
      fullName={user.fullName}
      username={user.username}
      schoolName={schoolName}
      schoolCode={schoolCode}
    >
      {children}
    </DashboardShell>
  );
}
