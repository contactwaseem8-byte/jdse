import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { PageHeader } from "@/components/ui";
import { SchoolsManager } from "@/components/schools/SchoolsManager";

export const metadata = { title: "Schools · EduVault" };

export default async function SchoolsPage() {
  const session = await getSession();
  if (!session) redirect("/login");
  if (session.role !== "super_admin") redirect("/dashboard");

  return (
    <>
      <PageHeader
        kicker="Network"
        title="Schools"
        description="Every school on the platform. New schools come pre-loaded with a customizable default form (name, parents, DOB, gender, phone, address)."
      />
      <SchoolsManager />
    </>
  );
}
