import Link from "next/link";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { counters, fieldDefinitions, schools, students, users } from "@/db/schema";
import { count, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { fetchStudents } from "@/lib/queries";
import { uploadStats } from "@/lib/storage";
import { formatSerial } from "@/lib/format";
import { PageHeader, SerialStamp } from "@/components/ui";
import { ApprovalsCard } from "@/components/dashboard/ApprovalsCard";
import {
  ArrowRight,
  Building2,
  Camera,
  HardDrive,
  School as SchoolIcon,
  Shapes,
  UserPlus,
  Users,
} from "lucide-react";

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  accent,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  sub?: string;
  accent?: boolean;
}) {
  return (
    <div className="card card-hover rise p-5">
      <div className="flex items-start justify-between">
        <span
          className={`grid size-10 place-items-center rounded-xl border ${
            accent
              ? "border-cobalt/25 bg-cobalt/10 text-cobalt"
              : "border-line bg-parchment/70 text-mute"
          }`}
        >
          <Icon className="size-[18px]" />
        </span>
      </div>
      <p className="mt-4 font-mono text-2xl font-semibold tracking-tight">{value}</p>
      <p className="mt-1 text-xs font-semibold uppercase tracking-[0.12em] text-mute">
        {label}
      </p>
      {sub && <p className="mt-1 text-[11px] text-mute/80">{sub}</p>}
    </div>
  );
}

export default async function DashboardOverview() {
  const session = await getSession();
  if (!session) redirect("/login");

  const isSchool = session.role === "school";
  const schoolScope = isSchool ? (session.schoolId ?? undefined) : undefined;

  const [studentCount] = await db
    .select({ n: count() })
    .from(students)
    .where(schoolScope ? eq(students.schoolId, schoolScope) : undefined);

  const [schoolCount] = await db.select({ n: count() }).from(schools);
  const [userCount] = await db.select({ n: count() }).from(users);
  const [pendingCount] = await db
    .select({ n: count() })
    .from(users)
    .where(eq(users.status, "pending"));

  const [fieldCount] = schoolScope
    ? await db
        .select({ n: count() })
        .from(fieldDefinitions)
        .where(eq(fieldDefinitions.schoolId, schoolScope))
    : [{ n: 0 }];

  const [counter] = await db
    .select()
    .from(counters)
    .where(eq(counters.id, "student_serial"));
  const nextSerial = (counter?.value ?? 0) + 1;

  const storage = session.role !== "school" ? await uploadStats() : null;

  const recent = await fetchStudents({
    schoolId: schoolScope,
    sort: "newest",
    limit: 6,
  });

  return (
    <>
      <PageHeader
        kicker={isSchool ? "School Console" : session.role === "admin" ? "Admin Console" : "Super Admin Console"}
        title={`Namaste, ${session.fullName.split(" ")[0]}`}
        description={
          isSchool
            ? "Register students with serial-stamped photos, customize your form, and keep your school's archive in order."
            : "Monitor every school's registry, approve access, and export the complete archive anytime."
        }
        actions={
          isSchool ? (
            <Link href="/dashboard/students/new" className="btn btn-primary">
              <UserPlus className="size-4" /> Add student
            </Link>
          ) : (
            <Link href="/dashboard/students" className="btn btn-primary">
              <SchoolIcon className="size-4" /> Browse registry
            </Link>
          )
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
        <StatCard
          icon={Camera}
          label={isSchool ? "Students recorded" : "Total students"}
          value={String(studentCount.n)}
          sub={`Next serial · #${formatSerial(nextSerial)}`}
          accent
        />
        {isSchool ? (
          <StatCard
            icon={Shapes}
            label="Custom form fields"
            value={String(fieldCount.n)}
            sub="Enabled + disabled"
          />
        ) : (
          <StatCard
            icon={Building2}
            label="Schools"
            value={String(schoolCount.n)}
            sub="Registered on platform"
          />
        )}
        {session.role === "super_admin" ? (
          <StatCard
            icon={Users}
            label="User accounts"
            value={String(userCount.n)}
            sub={pendingCount.n > 0 ? `${pendingCount.n} awaiting approval` : "All approved"}
          />
        ) : (
          <StatCard
            icon={SchoolIcon}
            label="Registry classes"
            value={String(new Set(recent.map((r) => r.className)).size) || "—"}
            sub="Among recent records"
          />
        )}
        {storage ? (
          <StatCard
            icon={HardDrive}
            label="Photo storage"
            value={`${(storage.bytes / 1024 / 1024).toFixed(1)} MB`}
            sub={`${storage.count} compressed photo${storage.count === 1 ? "" : "s"}`}
          />
        ) : (
          <div className="card card-hover rise flex flex-col justify-between p-5">
            <p className="text-xs font-semibold uppercase tracking-[0.12em] text-mute">
              Next unique serial
            </p>
            <p className="mt-2 font-mono text-3xl font-semibold tracking-tight text-cobalt">
              #{formatSerial(nextSerial)}
            </p>
            <p className="mt-1 text-[11px] text-mute/80">
              The next photo you capture becomes {formatSerial(nextSerial)}.jpg
            </p>
          </div>
        )}
      </div>

      {/* Pending approvals */}
      {session.role === "super_admin" && (
        <div className="mt-6">
          <ApprovalsCard />
        </div>
      )}

      {/* Recent students */}
      <section className="rise rise-2 mt-8">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-semibold uppercase tracking-[0.14em] text-mute">
            Recently added
          </h2>
          <Link
            href="/dashboard/students"
            className="flex items-center gap-1 text-[13px] font-semibold text-cobalt hover:underline"
          >
            View all <ArrowRight className="size-3.5" />
          </Link>
        </div>

        {recent.length === 0 ? (
          <div className="card grid place-items-center px-6 py-14 text-center">
            <p className="text-sm text-mute">
              No student records yet.{" "}
              {isSchool
                ? "Add your first student to start the archive."
                : "Records added by schools will surface here."}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-6">
            {recent.map((r) => (
              <Link
                key={r.id}
                href={`/dashboard/students/${r.id}`}
                className="card card-hover group overflow-hidden"
              >
                <div className="relative aspect-[4/5] overflow-hidden bg-parchment">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={`/api/photos/${r.photoFile}?v=${new Date(r.updatedAt).getTime()}`}
                    alt=""
                    className="size-full object-cover transition-transform duration-300 group-hover:scale-[1.04]"
                  />
                  <div className="absolute left-2 top-2">
                    <SerialStamp serial={r.serialNumber} />
                  </div>
                </div>
                <div className="p-3">
                  <p className="truncate text-[13px] font-semibold">
                    {Object.values(r.customData)[0] || "Student record"}
                  </p>
                  <p className="truncate font-mono text-[10px] uppercase tracking-wider text-mute">
                    {isSchool ? r.className : `${r.schoolCode} · ${r.className}`}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>
    </>
  );
}
