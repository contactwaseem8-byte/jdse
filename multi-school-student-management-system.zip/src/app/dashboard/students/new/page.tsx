import { redirect } from "next/navigation";
import { db } from "@/db";
import { counters, fieldDefinitions } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { formatSerial } from "@/lib/format";
import { PageHeader } from "@/components/ui";
import { StudentForm } from "@/components/students/StudentForm";

export const metadata = { title: "Add student · EduVault" };

export default async function NewStudentPage() {
  const session = await getSession();
  if (!session) redirect("/login");
  if (session.role !== "school" || !session.schoolId) redirect("/dashboard/students");

  const fields = await db
    .select()
    .from(fieldDefinitions)
    .where(eq(fieldDefinitions.schoolId, session.schoolId))
    .orderBy(asc(fieldDefinitions.sortOrder), asc(fieldDefinitions.id));

  const [counter] = await db
    .select()
    .from(counters)
    .where(eq(counters.id, "student_serial"));

  return (
    <>
      <PageHeader
        kicker="New Record"
        title="Register a student"
        description={`This record will receive serial #${formatSerial(
          (counter?.value ?? 0) + 1,
        )}, and the captured photo will be renamed to match it.`}
      />
      <StudentForm
        mode="create"
        fields={fields.map((f) => ({
          id: f.id,
          label: f.label,
          fieldKey: f.fieldKey,
          type: f.type,
          options: f.options,
          required: f.required,
          enabled: f.enabled,
        }))}
      />
    </>
  );
}
