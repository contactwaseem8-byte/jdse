import { notFound, redirect } from "next/navigation";
import { db } from "@/db";
import { fieldDefinitions, schools, students, users } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { StudentDetail } from "@/components/students/StudentDetail";

export const metadata = { title: "Student record · EduVault" };

export default async function StudentDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ edit?: string }>;
}) {
  const session = await getSession();
  if (!session) redirect("/login");

  const { id } = await params;
  const { edit } = await searchParams;

  const [row] = await db
    .select({
      id: students.id,
      serialNumber: students.serialNumber,
      className: students.className,
      photoFile: students.photoFile,
      customData: students.customData,
      createdAt: students.createdAt,
      updatedAt: students.updatedAt,
      schoolId: students.schoolId,
      schoolName: schools.name,
      schoolCode: schools.code,
      createdByName: users.fullName,
    })
    .from(students)
    .innerJoin(schools, eq(students.schoolId, schools.id))
    .leftJoin(users, eq(students.createdBy, users.id))
    .where(eq(students.id, Number(id)));

  if (!row) notFound();
  if (session.role === "school" && session.schoolId !== row.schoolId) notFound();

  const fields = await db
    .select()
    .from(fieldDefinitions)
    .where(eq(fieldDefinitions.schoolId, row.schoolId))
    .orderBy(asc(fieldDefinitions.sortOrder), asc(fieldDefinitions.id));

  return (
    <StudentDetail
      student={{
        ...row,
        createdAt: row.createdAt.toISOString(),
        updatedAt: row.updatedAt.toISOString(),
      }}
      fields={fields.map((f) => ({
        id: f.id,
        label: f.label,
        fieldKey: f.fieldKey,
        type: f.type,
        options: f.options,
        required: f.required,
        enabled: f.enabled,
      }))}
      role={session.role}
      startEditing={edit === "1" && session.role === "school"}
    />
  );
}
