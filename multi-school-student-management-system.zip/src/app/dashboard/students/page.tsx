import { redirect } from "next/navigation";
import { db } from "@/db";
import { schools } from "@/db/schema";
import { asc } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { PageHeader } from "@/components/ui";
import { StudentsExplorer } from "@/components/students/StudentsExplorer";

export const metadata = { title: "Students · EduVault" };

export default async function StudentsPage() {
  const session = await getSession();
  if (!session) redirect("/login");

  const allSchools =
    session.role === "school"
      ? []
      : await db
          .select({ id: schools.id, name: schools.name, code: schools.code })
          .from(schools)
          .orderBy(asc(schools.name));

  return (
    <>
      <PageHeader
        kicker="Registry"
        title={session.role === "school" ? "Your students" : "All schools · full registry"}
        description={
          session.role === "school"
            ? "Search, sort class-wise, edit or delete records — every photo is stamped with a unique serial."
            : "Every record across every school. Filter, search, then export as Excel or a ZIP folder of serial-named photos."
        }
      />
      <StudentsExplorer role={session.role} schools={allSchools} />
    </>
  );
}
