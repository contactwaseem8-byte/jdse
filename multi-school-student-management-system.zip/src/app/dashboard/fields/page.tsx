import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { PageHeader } from "@/components/ui";
import { FieldsManager } from "@/components/fields/FieldsManager";

export const metadata = { title: "Form fields · EduVault" };

export default async function FieldsPage() {
  const session = await getSession();
  if (!session) redirect("/login");
  if (session.role !== "school") redirect("/dashboard");

  return (
    <>
      <PageHeader
        kicker="Form Builder"
        title="Customize your student form"
        description="Choose exactly which details your school collects. Required fields are enforced, hidden fields disappear from the form, and the serial + photo are always captured."
      />
      <FieldsManager />
    </>
  );
}
