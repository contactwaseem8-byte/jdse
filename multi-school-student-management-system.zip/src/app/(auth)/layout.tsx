import type { ReactNode } from "react";
import Image from "next/image";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { Archive, Camera, FileSpreadsheet, FolderArchive } from "lucide-react";

const FEATURES = [
  { icon: Camera, text: "Mandatory photo capture with smart compression" },
  { icon: Archive, text: "Every student stamped with a unique serial — 0001, 0002…" },
  { icon: FolderArchive, text: "One-click ZIP of every photograph" },
  { icon: FileSpreadsheet, text: "Excel export with serials, class-wise" },
];

export default async function AuthLayout({ children }: { children: ReactNode }) {
  const session = await getSession();
  if (session) redirect("/dashboard");

  return (
    <main className="min-h-dvh grid lg:grid-cols-[1.05fr_1fr]">
      {/* Brand panel */}
      <aside className="relative hidden lg:flex flex-col justify-between overflow-hidden bg-ink text-cream p-10 xl:p-14">
        <Image
          src="/images/auth-hero.jpg"
          alt=""
          fill
          priority
          className="object-cover opacity-45 saturate-[0.82]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/60 to-ink/20" />

        <div className="relative rise">
          <Link href="/login" className="flex items-center gap-3">
            <span className="grid size-10 place-items-center rounded-xl bg-cobalt text-white font-mono font-semibold">
              EV
            </span>
            <span className="text-lg font-semibold tracking-tight">EduVault</span>
          </Link>
        </div>

        <div className="relative max-w-md rise rise-1">
          <p className="font-mono text-[11px] tracking-[0.28em] uppercase text-cream/60">
            Multi-School Registry
          </p>
          <h1 className="mt-4 text-[2.6rem] leading-[1.04] font-semibold tracking-tight">
            Every student.
            <br />
            One serial.
            <br />
            <span className="text-[#9db0ff]">Zero chaos.</span>
          </h1>
          <ul className="mt-8 space-y-3.5">
            {FEATURES.map((f) => (
              <li key={f.text} className="flex items-center gap-3 text-sm text-cream/80">
                <span className="grid size-8 shrink-0 place-items-center rounded-lg border border-cream/15 bg-cream/5">
                  <f.icon className="size-4" />
                </span>
                {f.text}
              </li>
            ))}
          </ul>
        </div>

        <p className="relative font-mono text-[10px] tracking-[0.2em] uppercase text-cream/40 rise rise-2">
          EDU-REGISTRY SYSTEM · SERIALIZED PHOTO ARCHIVE
        </p>
      </aside>

      {/* Form panel */}
      <section className="flex items-center justify-center p-6 sm:p-10">
        <div className="w-full max-w-[400px] rise">{children}</div>
      </section>
    </main>
  );
}
