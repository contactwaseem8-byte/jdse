import type { Metadata } from "next";
import { db } from "@/db";
import { schools } from "@/db/schema";
import { asc } from "drizzle-orm";
import { RegisterForm } from "@/components/auth/RegisterForm";

export const metadata: Metadata = { title: "Request access · EduVault" };

export default async function RegisterPage() {
  const allSchools = await db
    .select({ id: schools.id, name: schools.name, code: schools.code })
    .from(schools)
    .orderBy(asc(schools.name));

  return <RegisterForm schools={allSchools} />;
}
