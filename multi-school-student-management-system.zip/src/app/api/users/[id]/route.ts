import { NextResponse } from "next/server";
import { db } from "@/db";
import { schools, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireAuth, apiError, ApiError } from "@/lib/api-guard";
import { seedDefaultFields } from "@/lib/seed";

export const runtime = "nodejs";

type Ctx = { params: Promise<{ id: string }> };

/** Approve / reject / reset a user. */
export async function PATCH(req: Request, ctx: Ctx) {
  try {
    const session = await requireAuth(["super_admin"]);
    const { id } = await ctx.params;
    const userId = Number(id);
    if (userId === session.uid) throw new ApiError(400, "You cannot modify your own account.");

    const body = await req.json().catch(() => null);
    const status = body?.status;
    if (!["approved", "rejected", "pending"].includes(String(status))) {
      throw new ApiError(400, "Invalid status.");
    }

    const [user] = await db.select().from(users).where(eq(users.id, userId));
    if (!user) throw new ApiError(404, "User not found.");

    let schoolId = user.schoolId;

    // Approving a school user that requested a brand-new school? Create it.
    if (status === "approved" && user.role === "school" && !user.schoolId) {
      if (user.requestedSchoolName) {
        const base = user.requestedSchoolName
          .replace(/[^a-zA-Z ]/g, "")
          .split(" ")
          .filter(Boolean)
          .slice(0, 3)
          .map((w) => w[0])
          .join("")
          .toUpperCase() || "SCH";
        const [school] = await db
          .insert(schools)
          .values({ name: user.requestedSchoolName, code: `${base}-${user.id}` })
          .returning();
        await seedDefaultFields(school.id);
        schoolId = school.id;
      } else {
        throw new ApiError(
          400,
          "This school account has no school assigned and no requested school name.",
        );
      }
    }

    const [updated] = await db
      .update(users)
      .set({ status: status as "approved" | "rejected" | "pending", schoolId })
      .where(eq(users.id, userId))
      .returning({ id: users.id });

    return NextResponse.json({ ok: true, id: updated.id, schoolId });
  } catch (err) {
    return apiError(err);
  }
}

export async function DELETE(_req: Request, ctx: Ctx) {
  try {
    const session = await requireAuth(["super_admin"]);
    const { id } = await ctx.params;
    const userId = Number(id);
    if (userId === session.uid) throw new ApiError(400, "You cannot delete your own account.");
    await db.delete(users).where(eq(users.id, userId));
    return NextResponse.json({ ok: true });
  } catch (err) {
    return apiError(err);
  }
}
