import { NextResponse } from "next/server";
import { db } from "@/db";
import { schools, users } from "@/db/schema";
import { desc, eq, ne } from "drizzle-orm";
import { requireAuth, apiError, ApiError, sanitizeUsername } from "@/lib/api-guard";
import { hashPassword } from "@/lib/auth";

export const runtime = "nodejs";

export async function GET() {
  try {
    const session = await requireAuth(["super_admin"]);
    const rows = await db
      .select({
        id: users.id,
        username: users.username,
        fullName: users.fullName,
        role: users.role,
        status: users.status,
        schoolId: users.schoolId,
        requestedSchoolName: users.requestedSchoolName,
        createdAt: users.createdAt,
        schoolName: schools.name,
        schoolCode: schools.code,
      })
      .from(users)
      .leftJoin(schools, eq(users.schoolId, schools.id))
      .where(ne(users.id, session.uid))
      .orderBy(desc(users.createdAt));
    return NextResponse.json({ users: rows });
  } catch (err) {
    return apiError(err);
  }
}

export async function POST(req: Request) {
  try {
    await requireAuth(["super_admin"]);
    const body = await req.json().catch(() => null);
    const fullName = String(body?.fullName ?? "").trim();
    const username = sanitizeUsername(String(body?.username ?? ""));
    const password = String(body?.password ?? "");
    const role = body?.role === "admin" ? "admin" : "school";
    const schoolId = body?.schoolId ? Number(body.schoolId) : null;

    if (!fullName || !username || !password) {
      throw new ApiError(400, "Full name, username and password are required.");
    }
    if (password.length < 6) {
      throw new ApiError(400, "Password must be at least 6 characters.");
    }
    if (role === "school" && !schoolId) {
      throw new ApiError(400, "Pick a school for this account.");
    }
    if (schoolId) {
      const [s] = await db.select().from(schools).where(eq(schools.id, schoolId));
      if (!s) throw new ApiError(400, "School not found.");
    }
    const [existing] = await db.select().from(users).where(eq(users.username, username));
    if (existing) throw new ApiError(409, "That username is already taken.");

    const [created] = await db
      .insert(users)
      .values({
        fullName,
        username,
        passwordHash: await hashPassword(password),
        role,
        status: "approved",
        schoolId: role === "school" ? schoolId : null,
      })
      .returning({ id: users.id });

    return NextResponse.json({ ok: true, id: created.id });
  } catch (err) {
    return apiError(err);
  }
}
