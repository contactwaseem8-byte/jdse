import { NextResponse } from "next/server";
import { db } from "@/db";
import { schools, students } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireAuth, apiError, ApiError } from "@/lib/api-guard";
import { deletePhoto } from "@/lib/storage";

export const runtime = "nodejs";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, ctx: Ctx) {
  try {
    await requireAuth(["super_admin"]);
    const { id } = await ctx.params;
    const schoolId = Number(id);
    const body = await req.json().catch(() => null);

    const name = String(body?.name ?? "").trim();
    const address = String(body?.address ?? "").trim() || null;
    const contactPhone = String(body?.contactPhone ?? "").trim() || null;
    if (!name) throw new ApiError(400, "School name is required.");

    const [school] = await db
      .update(schools)
      .set({ name, address, contactPhone })
      .where(eq(schools.id, schoolId))
      .returning({ id: schools.id });
    if (!school) throw new ApiError(404, "School not found.");
    return NextResponse.json({ ok: true });
  } catch (err) {
    return apiError(err);
  }
}

export async function DELETE(_req: Request, ctx: Ctx) {
  try {
    await requireAuth(["super_admin"]);
    const { id } = await ctx.params;
    const schoolId = Number(id);

    const photoRows = await db
      .select({ photoFile: students.photoFile })
      .from(students)
      .where(eq(students.schoolId, schoolId));

    await db.delete(schools).where(eq(schools.id, schoolId)); // cascades students + fields

    for (const p of photoRows) await deletePhoto(p.photoFile);

    return NextResponse.json({ ok: true });
  } catch (err) {
    return apiError(err);
  }
}
