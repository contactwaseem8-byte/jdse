import { NextResponse } from "next/server";
import { db } from "@/db";
import { schools, students, users } from "@/db/schema";
import { asc, count, eq } from "drizzle-orm";
import { requireAuth, apiError, ApiError } from "@/lib/api-guard";
import { seedDefaultFields } from "@/lib/seed";

export const runtime = "nodejs";

export async function GET() {
  try {
    await requireAuth();
    const rows = await db
      .select({
        id: schools.id,
        name: schools.name,
        code: schools.code,
        address: schools.address,
        contactPhone: schools.contactPhone,
        createdAt: schools.createdAt,
        studentCount: count(students.id),
      })
      .from(schools)
      .leftJoin(students, eq(students.schoolId, schools.id))
      .groupBy(schools.id)
      .orderBy(asc(schools.name));

    const userCounts = await db
      .select({ schoolId: users.schoolId, n: count(users.id) })
      .from(users)
      .groupBy(users.schoolId);

    const map = new Map(userCounts.map((u) => [u.schoolId, u.n]));
    return NextResponse.json({
      schools: rows.map((r) => ({ ...r, userCount: map.get(r.id) ?? 0 })),
    });
  } catch (err) {
    return apiError(err);
  }
}

export async function POST(req: Request) {
  try {
    await requireAuth(["super_admin"]);
    const body = await req.json().catch(() => null);
    const name = String(body?.name ?? "").trim();
    const code = String(body?.code ?? "").trim().toUpperCase();
    const address = String(body?.address ?? "").trim() || null;
    const contactPhone = String(body?.contactPhone ?? "").trim() || null;

    if (!name || !code) throw new ApiError(400, "School name and code are required.");
    if (!/^[A-Z0-9-]{2,20}$/.test(code)) {
      throw new ApiError(400, "Code must be 2–20 chars: A–Z, 0–9, dashes.");
    }

    const [existing] = await db.select().from(schools).where(eq(schools.code, code));
    if (existing) throw new ApiError(409, "A school with this code already exists.");

    const [school] = await db
      .insert(schools)
      .values({ name, code, address, contactPhone })
      .returning();
    await seedDefaultFields(school.id);

    return NextResponse.json({ ok: true, id: school.id });
  } catch (err) {
    return apiError(err);
  }
}
