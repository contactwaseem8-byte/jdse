import { NextResponse } from "next/server";
import { db } from "@/db";
import { fieldDefinitions, fieldTypes } from "@/db/schema";
import { and, asc, eq } from "drizzle-orm";
import { requireAuth, requireSchool, apiError, ApiError } from "@/lib/api-guard";

export const runtime = "nodejs";

function slugify(label: string) {
  return (
    label
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "_")
      .replace(/^_+|_+$/g, "")
      .slice(0, 40) || "field"
  );
}

export async function GET(req: Request) {
  try {
    const session = await requireAuth();
    const { searchParams } = new URL(req.url);
    let schoolId: number;
    if (session.role === "school") {
      schoolId = await requireSchool(session);
    } else {
      const q = searchParams.get("schoolId");
      if (!q) throw new ApiError(400, "schoolId is required for non-school accounts.");
      schoolId = Number(q);
    }

    const rows = await db
      .select()
      .from(fieldDefinitions)
      .where(eq(fieldDefinitions.schoolId, schoolId))
      .orderBy(asc(fieldDefinitions.sortOrder), asc(fieldDefinitions.id));
    return NextResponse.json({ fields: rows });
  } catch (err) {
    return apiError(err);
  }
}

export async function POST(req: Request) {
  try {
    const session = await requireAuth(["school"]);
    const schoolId = await requireSchool(session);
    const body = await req.json().catch(() => null);

    const label = String(body?.label ?? "").trim();
    const type = fieldTypes.includes(body?.type) ? (body.type as (typeof fieldTypes)[number]) : "text";
    const required = Boolean(body?.required);
    const options: string[] = Array.isArray(body?.options)
      ? body.options.map((o: unknown) => String(o).trim()).filter(Boolean)
      : [];

    if (!label) throw new ApiError(400, "Field label is required.");
    if (type === "select" && options.length === 0) {
      throw new ApiError(400, "Add at least one option for a dropdown field.");
    }

    const base = slugify(label);
    let key = base;
    for (let i = 2; ; i++) {
      const [dupe] = await db
        .select({ id: fieldDefinitions.id })
        .from(fieldDefinitions)
        .where(and(eq(fieldDefinitions.schoolId, schoolId), eq(fieldDefinitions.fieldKey, key)));
      if (!dupe) break;
      key = `${base}_${i}`;
    }

    const existing = await db
      .select({ sortOrder: fieldDefinitions.sortOrder })
      .from(fieldDefinitions)
      .where(eq(fieldDefinitions.schoolId, schoolId));
    const nextOrder = existing.reduce((m, r) => Math.max(m, r.sortOrder), -1) + 1;

    const [field] = await db
      .insert(fieldDefinitions)
      .values({
        schoolId,
        label,
        fieldKey: key,
        type,
        options,
        required,
        enabled: true,
        sortOrder: nextOrder,
      })
      .returning();

    return NextResponse.json({ ok: true, field });
  } catch (err) {
    return apiError(err);
  }
}
