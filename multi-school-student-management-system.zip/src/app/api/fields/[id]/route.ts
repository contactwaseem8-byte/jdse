import { NextResponse } from "next/server";
import { db } from "@/db";
import { fieldDefinitions, fieldTypes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireAuth, requireSchool, apiError, ApiError } from "@/lib/api-guard";

export const runtime = "nodejs";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, ctx: Ctx) {
  try {
    const session = await requireAuth(["school"]);
    const schoolId = await requireSchool(session);
    const { id } = await ctx.params;
    const fieldId = Number(id);
    const body = await req.json().catch(() => null);

    const [field] = await db
      .select()
      .from(fieldDefinitions)
      .where(eq(fieldDefinitions.id, fieldId));
    if (!field || field.schoolId !== schoolId) throw new ApiError(404, "Field not found.");

    const patch: Partial<typeof fieldDefinitions.$inferInsert> = {};
    if (body?.label !== undefined) {
      const label = String(body.label).trim();
      if (!label) throw new ApiError(400, "Label cannot be empty.");
      patch.label = label;
    }
    if (body?.type !== undefined && fieldTypes.includes(body.type)) {
      patch.type = body.type;
    }
    if (body?.options !== undefined) {
      patch.options = Array.isArray(body.options)
        ? body.options.map((o: unknown) => String(o).trim()).filter(Boolean)
        : [];
    }
    if (body?.required !== undefined) patch.required = Boolean(body.required);
    if (body?.enabled !== undefined) patch.enabled = Boolean(body.enabled);
    if (body?.sortOrder !== undefined) patch.sortOrder = Number(body.sortOrder) || 0;

    const [updated] = await db
      .update(fieldDefinitions)
      .set(patch)
      .where(eq(fieldDefinitions.id, fieldId))
      .returning();
    return NextResponse.json({ ok: true, field: updated });
  } catch (err) {
    return apiError(err);
  }
}

export async function DELETE(_req: Request, ctx: Ctx) {
  try {
    const session = await requireAuth(["school"]);
    const schoolId = await requireSchool(session);
    const { id } = await ctx.params;
    const fieldId = Number(id);

    const [field] = await db
      .select()
      .from(fieldDefinitions)
      .where(eq(fieldDefinitions.id, fieldId));
    if (!field || field.schoolId !== schoolId) throw new ApiError(404, "Field not found.");

    await db.delete(fieldDefinitions).where(eq(fieldDefinitions.id, fieldId));
    return NextResponse.json({ ok: true });
  } catch (err) {
    return apiError(err);
  }
}
