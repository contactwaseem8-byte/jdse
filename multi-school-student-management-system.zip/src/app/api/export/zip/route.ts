import JSZip from "jszip";
import * as XLSX from "xlsx";
import { requireAuth, requireSchool, apiError } from "@/lib/api-guard";
import { fetchStudents, getFieldMap } from "@/lib/queries";
import { readPhoto } from "@/lib/storage";
import { formatSerial } from "@/lib/format";

export const runtime = "nodejs";

export async function GET(req: Request) {
  try {
    const session = await requireAuth();
    const { searchParams } = new URL(req.url);

    let schoolId: number | undefined;
    if (session.role === "school") {
      schoolId = await requireSchool(session);
    } else {
      const q = searchParams.get("schoolId");
      schoolId = q ? Number(q) : undefined;
    }
    const className = searchParams.get("className") || undefined;
    const q = searchParams.get("q") || undefined;

    const rows = await fetchStudents({ schoolId, className, q, sort: "serial_asc", limit: 20000 });
    const schoolIds = [...new Set(rows.map((r) => r.schoolId))];
    const fieldMap = await getFieldMap(schoolIds);

    const labelKeys = new Map<string, string>();
    for (const sid of schoolIds) {
      for (const f of fieldMap.get(sid) ?? []) {
        if (!labelKeys.has(f.label)) labelKeys.set(f.label, f.fieldKey);
      }
    }
    const labels = [...labelKeys.keys()];

    const data = rows.map((r) => {
      const out: Record<string, string | number> = { "Serial No": formatSerial(r.serialNumber) };
      if (!schoolId) out["School"] = `${r.schoolName} (${r.schoolCode})`;
      out["Class"] = r.className;
      out["Photo File"] = r.photoFile;
      const fields = fieldMap.get(r.schoolId) ?? [];
      for (const label of labels) {
        const field = fields.find((f) => f.label === label);
        out[label] = field ? (r.customData[field.fieldKey] ?? "") : "";
      }
      return out;
    });

    const ws = XLSX.utils.json_to_sheet(data.length ? data : [{ "Serial No": "" }]);
    ws["!cols"] = [{ wch: 10 }, { wch: 30 }, { wch: 14 }, { wch: 12 }, ...labels.map(() => ({ wch: 22 }))];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Students");
    const excelBuf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" }) as Buffer;

    // Build the ZIP: photos grouped by school code, named by unique serial.
    const zip = new JSZip();
    zip.file("students.xlsx", excelBuf);
    zip.file(
      "README.txt",
      [
        "EduVault student archive export",
        `Generated: ${new Date().toISOString()}`,
        `Records: ${rows.length}`,
        "",
        "photos/<SCHOOL-CODE>/<SERIAL>.jpg  — every photo is named after the",
        "student's globally unique serial number (see students.xlsx).",
      ].join("\n"),
    );

    let added = 0;
    for (const r of rows) {
      const buf = await readPhoto(r.photoFile);
      if (!buf) continue;
      zip.file(`photos/${r.schoolCode}/${r.photoFile}`, buf);
      added++;
    }

    const zipBuf = await zip.generateAsync({
      type: "nodebuffer",
      compression: "DEFLATE",
      compressionOptions: { level: 6 },
    });

    const scope = schoolId ? `school-${schoolId}` : "all-schools";
    const stamp = new Date().toISOString().slice(0, 10);
    return new Response(new Uint8Array(zipBuf), {
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename="eduvault-${scope}-${stamp}.zip"`,
        "X-Photos-Added": String(added),
      },
    });
  } catch (err) {
    return apiError(err);
  }
}
