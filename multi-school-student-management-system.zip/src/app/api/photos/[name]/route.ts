import { NextResponse } from "next/server";
import { requireAuth, apiError, ApiError } from "@/lib/api-guard";
import { readPhoto } from "@/lib/storage";

export const runtime = "nodejs";

type Ctx = { params: Promise<{ name: string }> };

/** Serves a serial-named student photo (e.g. 0001.jpg). Auth required. */
export async function GET(_req: Request, ctx: Ctx) {
  try {
    await requireAuth();
    const { name } = await ctx.params;
    if (!/^\d{3,}\.(jpg|jpeg|png|webp)$/i.test(name)) {
      throw new ApiError(400, "Invalid photo name.");
    }
    const buf = await readPhoto(name);
    if (!buf) throw new ApiError(404, "Photo not found.");

    const type = name.toLowerCase().endsWith(".png")
      ? "image/png"
      : name.toLowerCase().endsWith(".webp")
        ? "image/webp"
        : "image/jpeg";

    return new NextResponse(new Uint8Array(buf), {
      headers: {
        "Content-Type": type,
        "Cache-Control": "private, max-age=300",
      },
    });
  } catch (err) {
    return apiError(err);
  }
}
