import { NextResponse } from "next/server";
import { db } from "@/db";
import { fieldDefinitions, schools, students } from "@/db/schema";
import { and, asc, eq } from "drizzle-orm";
import { requireAuth, requireSchool, apiError, ApiError } from "@/lib/api-guard";
import { deletePhoto, savePhoto } from "@/lib/storage";

export const runtime = "nodejs";

type Ctx = { params: Promise<{ id: string }> };
const MAX_PHOTO_BYTES = 8 * 1024 * 1024;

async function loadStudent(id: number) {
  const [row] = await db
    .select({
      id: students.id,
      serialNumber: students.serialNumber,
      className: students.className,
      photoFile: students.photoFile,
      customData: students.customData,
      createdAt: students.createdAt,
      updatedAt: students.updatedAt,
      schoolId: students.schoolId,
      schoolName: schools.name,
      schoolCode: schools.code,
    })
    .from(students)
    .innerJoin(schools, eq(students.schoolId, schools.id))
    .where(eq(students.id, id));
  return row ?? null;
}

export async function GET(_req: Request, ctx: Ctx) {
  try {
    const session = await requireAuth();
    const { id } = await ctx.params;
    const student = await loadStudent(Number(id));
    if (!student) throw new ApiError(404, "Student not found.");

    if (session.role === "school" && session.schoolId !== student.schoolId) {
      throw new ApiError(403, "This student belongs to another school.");
    }

    const fields = await db
      .select()
      .from(fieldDefinitions)
      .where(eq(fieldDefinitions.schoolId, student.schoolId))
      .orderBy(asc(fieldDefinitions.sortOrder), asc(fieldDefinitions.id));

    return NextResponse.json({ student, fields });
  } catch (err) {
    return apiError(err);
  }
}

export async function PATCH(req: Request, ctx: Ctx) {
  try {
    const session = await requireAuth(["school"]);
    const schoolId = await requireSchool(session);
    const { id } = await ctx.params;
    const student = await loadStudent(Number(id));
    if (!student || student.schoolId !== schoolId) {
      throw new ApiError(404, "Student not found in your school.");
    }

    const form = await req.formData();
    const className = String(form.get("className") ?? "").trim();
    const rawFields = String(form.get("data") ?? "{}");
    const photo = form.get("photo");

    if (!className) throw new ApiError(400, "Class is required.");

    let provided: Record<string, string> = {};
    try {
      const parsed = JSON.parse(rawFields);
      if (parsed && typeof parsed === "object") {
        for (const [k, v] of Object.entries(parsed)) {
          if (typeof v === "string") provided[k] = v.trim();
        }
      }
    } catch {
      throw new ApiError(400, "Invalid field payload.");
    }

    const fields = await db
      .select()
      .from(fieldDefinitions)
      .where(eq(fieldDefinitions.schoolId, schoolId));

    const customData: Record<string, string> = {};
    for (const f of fields) {
      if (!f.enabled) {
        // Preserve values of disabled fields if the form didn't re-send them
        if (provided[f.fieldKey] === undefined && student.customData[f.fieldKey]) {
          customData[f.fieldKey] = student.customData[f.fieldKey];
        }
        continue;
      }
      const value = provided[f.fieldKey] ?? "";
      if (f.required && !value) throw new ApiError(400, `"${f.label}" is required.`);
      if (f.type === "select" && value && !f.options.includes(value)) {
        throw new ApiError(400, `"${f.label}" has an invalid option.`);
      }
      if (value) customData[f.fieldKey] = value.slice(0, 500);
    }

    if (photo instanceof File) {
      if (!photo.type.startsWith("image/")) throw new ApiError(400, "Photo must be an image.");
      if (photo.size > MAX_PHOTO_BYTES) throw new ApiError(400, "Photo is over 8 MB.");
      if (photo.size > 0) {
        const buffer = Buffer.from(await photo.arrayBuffer());
        await savePhoto(student.photoFile, buffer); // overwrite same serial-named file
      }
    }

    await db
      .update(students)
      .set({ className, customData, updatedAt: new Date() })
      .where(and(eq(students.id, student.id), eq(students.schoolId, schoolId)));

    return NextResponse.json({ ok: true, serial: student.serialNumber });
  } catch (err) {
    return apiError(err);
  }
}

export async function DELETE(_req: Request, ctx: Ctx) {
  try {
    const session = await requireAuth(["school"]);
    const schoolId = await requireSchool(session);
    const { id } = await ctx.params;
    const student = await loadStudent(Number(id));
    if (!student || student.schoolId !== schoolId) {
      throw new ApiError(404, "Student not found in your school.");
    }

    await db
      .delete(students)
      .where(and(eq(students.id, student.id), eq(students.schoolId, schoolId)));
    await deletePhoto(student.photoFile);

    return NextResponse.json({ ok: true });
  } catch (err) {
    return apiError(err);
  }
}
