import { NextResponse } from "next/server";
import { db } from "@/db";
import { fieldDefinitions, students } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireAuth, requireSchool, apiError, ApiError } from "@/lib/api-guard";
import { allocateSerial, fetchStudents, getClasses, getFieldMap } from "@/lib/queries";
import { savePhoto } from "@/lib/storage";
import { formatSerial } from "@/lib/format";

export const runtime = "nodejs";

const MAX_PHOTO_BYTES = 8 * 1024 * 1024;

export async function GET(req: Request) {
  try {
    const session = await requireAuth();
    const { searchParams } = new URL(req.url);

    let schoolId: number | undefined;
    if (session.role === "school") {
      schoolId = await requireSchool(session);
    } else {
      const q = searchParams.get("schoolId");
      schoolId = q ? Number(q) : undefined;
    }

    const className = searchParams.get("className") || undefined;
    const q = searchParams.get("q") || undefined;
    const sort = (searchParams.get("sort") || "serial_asc") as
      | "serial_asc"
      | "serial_desc"
      | "class_asc"
      | "newest";

    const rows = await fetchStudents({ schoolId, className, q, sort });

    const schoolIds = [...new Set(rows.map((r) => r.schoolId))];
    const fieldMap = await getFieldMap(schoolIds);
    const classes = await getClasses(schoolId);

    return NextResponse.json({
      students: rows,
      classes,
      fields: Object.fromEntries(fieldMap),
    });
  } catch (err) {
    return apiError(err);
  }
}

export async function POST(req: Request) {
  try {
    const session = await requireAuth(["school"]);
    const schoolId = await requireSchool(session);

    const form = await req.formData();
    const className = String(form.get("className") ?? "").trim();
    const rawFields = String(form.get("data") ?? "{}");
    const photo = form.get("photo");

    if (!className) throw new ApiError(400, "Class is required.");
    if (!(photo instanceof File)) {
      throw new ApiError(400, "A student photo is mandatory. Capture or upload one.");
    }
    if (!photo.type.startsWith("image/")) {
      throw new ApiError(400, "Photo must be an image file.");
    }
    if (photo.size === 0) throw new ApiError(400, "Photo file is empty.");
    if (photo.size > MAX_PHOTO_BYTES) {
      throw new ApiError(400, "Photo is over 8 MB — please re-compress it.");
    }

    // Validate / sanitize custom values against the school's enabled fields.
    let provided: Record<string, string> = {};
    try {
      const parsed = JSON.parse(rawFields);
      if (parsed && typeof parsed === "object") {
        for (const [k, v] of Object.entries(parsed)) {
          if (typeof v === "string") provided[k] = v.trim();
        }
      }
    } catch {
      throw new ApiError(400, "Invalid field payload.");
    }

    const fields = await db
      .select()
      .from(fieldDefinitions)
      .where(eq(fieldDefinitions.schoolId, schoolId));

    const customData: Record<string, string> = {};
    for (const f of fields) {
      if (!f.enabled) continue;
      const value = provided[f.fieldKey] ?? "";
      if (f.required && !value) {
        throw new ApiError(400, `"${f.label}" is required.`);
      }
      if (f.type === "select" && value && !f.options.includes(value)) {
        throw new ApiError(400, `"${f.label}" has an invalid option.`);
      }
      if (value) customData[f.fieldKey] = value.slice(0, 500);
    }

    // Allocate the globally-unique serial FIRST — the photo is renamed to it.
    const serial = await allocateSerial();
    const fileName = `${formatSerial(serial)}.jpg`;

    const buffer = Buffer.from(await photo.arrayBuffer());
    await savePhoto(fileName, buffer);

    const [created] = await db
      .insert(students)
      .values({
        schoolId,
        serialNumber: serial,
        className,
        photoFile: fileName,
        customData,
        createdBy: session.uid,
      })
      .returning({ id: students.id });

    return NextResponse.json({ ok: true, id: created.id, serial, fileName });
  } catch (err) {
    return apiError(err);
  }
}
