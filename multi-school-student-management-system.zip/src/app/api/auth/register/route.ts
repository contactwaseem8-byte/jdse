import { NextResponse } from "next/server";
import { db } from "@/db";
import { schools, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "@/lib/auth";
import { sanitizeUsername } from "@/lib/api-guard";

export const runtime = "nodejs";

/**
 * Public registration request. Accounts are created as `pending` and must be
 * approved by the Super Admin before they can sign in.
 */
export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    const fullName = String(body?.fullName ?? "").trim();
    const username = sanitizeUsername(String(body?.username ?? ""));
    const password = String(body?.password ?? "");
    const role = body?.role === "admin" ? "admin" : "school";
    const schoolId = body?.schoolId ? Number(body.schoolId) : null;
    const requestedSchoolName = String(body?.requestedSchoolName ?? "").trim();

    if (!fullName || !username || !password) {
      return NextResponse.json(
        { error: "Full name, username and password are required." },
        { status: 400 },
      );
    }
    if (password.length < 6) {
      return NextResponse.json(
        { error: "Password must be at least 6 characters." },
        { status: 400 },
      );
    }
    if (role === "school" && !schoolId && !requestedSchoolName) {
      return NextResponse.json(
        { error: "Select your school, or enter a new school name." },
        { status: 400 },
      );
    }

    if (schoolId) {
      const [s] = await db.select().from(schools).where(eq(schools.id, schoolId));
      if (!s) {
        return NextResponse.json({ error: "Selected school not found." }, { status: 400 });
      }
    }

    const [existing] = await db.select().from(users).where(eq(users.username, username));
    if (existing) {
      return NextResponse.json(
        { error: "That username is already taken." },
        { status: 409 },
      );
    }

    await db.insert(users).values({
      fullName,
      username,
      passwordHash: await hashPassword(password),
      role,
      status: "pending",
      schoolId: role === "school" ? schoolId : null,
      requestedSchoolName: role === "school" && !schoolId ? requestedSchoolName : null,
    });

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("[register]", err);
    return NextResponse.json({ error: "Server error." }, { status: 500 });
  }
}
