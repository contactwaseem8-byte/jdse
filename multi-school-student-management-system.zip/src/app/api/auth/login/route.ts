import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { createSession, verifyPassword } from "@/lib/auth";
import { sanitizeUsername } from "@/lib/api-guard";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    const username = sanitizeUsername(String(body?.username ?? ""));
    const password = String(body?.password ?? "");
    if (!username || !password) {
      return NextResponse.json(
        { error: "Username and password are required." },
        { status: 400 },
      );
    }

    const [user] = await db.select().from(users).where(eq(users.username, username));
    if (!user || !(await verifyPassword(password, user.passwordHash))) {
      return NextResponse.json(
        { error: "Invalid username or password." },
        { status: 401 },
      );
    }
    if (user.status === "pending") {
      return NextResponse.json(
        { error: "Your account is awaiting approval from the Super Admin." },
        { status: 403 },
      );
    }
    if (user.status === "rejected") {
      return NextResponse.json(
        { error: "Your registration was rejected. Contact the Super Admin." },
        { status: 403 },
      );
    }

    await createSession({
      uid: user.id,
      username: user.username,
      fullName: user.fullName,
      role: user.role,
      schoolId: user.schoolId,
    });

    return NextResponse.json({
      ok: true,
      user: {
        uid: user.id,
        username: user.username,
        fullName: user.fullName,
        role: user.role,
        schoolId: user.schoolId,
      },
    });
  } catch (err) {
    console.error("[login]", err);
    return NextResponse.json({ error: "Server error." }, { status: 500 });
  }
}
