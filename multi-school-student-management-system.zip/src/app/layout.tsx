import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Space_Grotesk, IBM_Plex_Mono } from "next/font/google";
import { Toaster } from "sonner";
import "./globals.css";

const grotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-grotesk",
  weight: ["400", "500", "600", "700"],
});

const plex = IBM_Plex_Mono({
  subsets: ["latin"],
  variable: "--font-plex",
  weight: ["400", "500", "600"],
});

export const metadata: Metadata = {
  title: "EduVault · Multi-School Student Registry",
  description:
    "Central student data collection platform for multiple schools — customizable fields, serial-stamped photo capture, and one-click Excel / ZIP export.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${grotesk.variable} ${plex.variable}`}>
      <body className="grain">
        {children}
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: "#faf8f1",
              border: "1px solid #ddd6c3",
              color: "#17140c",
            },
          }}
        />
      </body>
    </html>
  );
}
