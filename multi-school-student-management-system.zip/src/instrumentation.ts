export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    try {
      const { ensureSeed } = await import("@/lib/seed");
      await ensureSeed();
    } catch (err) {
      // Tables may not exist yet on the very first boot before drizzle-kit push.
      console.warn("[seed] Skipped:", err instanceof Error ? err.message : err);
    }
  }
}
